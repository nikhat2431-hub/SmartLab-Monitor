import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Lab, 
  Sensor, 
  Device, 
  Alert, 
  SystemSettings, 
  HourlyTelemetry, 
  UserProfile, 
  UserRole,
  SensorThresholds,
  OccupancyStatus
} from '../types';
import { 
  INITIAL_LABS, 
  INITIAL_SENSORS, 
  INITIAL_DEVICES, 
  INITIAL_ALERTS, 
  INITIAL_SETTINGS, 
  INITIAL_HOURLY_DATA, 
  INITIAL_USER 
} from '../data/initialData';

interface IoTContextType {
  labs: Lab[];
  sensors: Sensor[];
  devices: Device[];
  alerts: Alert[];
  settings: SystemSettings;
  hourlyData: HourlyTelemetry[];
  currentUser: UserProfile;
  isSimulating: boolean;
  lastTickTime: Date;
  activeFilterLab: string;
  setActiveFilterLab: (labId: string) => void;
  toggleSimulation: () => void;
  setSimulationSpeed: (speed: number) => void;
  toggleDeviceState: (deviceId: string, targetState: 'ON' | 'OFF') => Promise<boolean>;
  updateDeviceAutoShutoff: (deviceId: string, enabled: boolean, delay: number) => void;
  updateSensorThresholds: (sensorId: string, thresholds: SensorThresholds) => void;
  acknowledgeAlert: (alertId: string) => void;
  resolveAlert: (alertId: string) => void;
  deleteAlert: (alertId: string) => void;
  clearAllAlerts: () => void;
  updateLab: (lab: Lab) => void;
  addLab: (newLab: Omit<Lab, 'id' | 'totalPowerWatts' | 'dailyKwh' | 'alertCount'>) => void;
  deleteLab: (labId: string) => void;
  updateSettings: (newSettings: Partial<SystemSettings>) => void;
  switchUserRole: (role: UserRole) => void;
  adjustOccupancy: (labId: string, newCount: number) => void;
  triggerSimulationScenario: (scenario: 'vacant_waste' | 'temp_spike' | 'sensor_disconnect' | 'reset') => void;
  exportDataCSV: (type: 'energy' | 'occupancy' | 'sensors' | 'all') => void;
  // Computed KPI metrics
  totalCurrentWatts: number;
  totalDailyKwh: number;
  totalOccupancy: number;
  overallOccupancyStatus: OccupancyStatus;
  estimatedDailyCost: number;
  energyEfficiencyScore: number;
  activeAlertCount: number;
  unresolvedAlerts: Alert[];
  avgTemp: number;
  avgHumidity: number;
  totalDevicesOnline: number;
  totalSensorsOnline: number;
}

const IoTContext = createContext<IoTContextType | undefined>(undefined);

const STORAGE_KEYS = {
  LABS: 'smartlab_labs_v1',
  SENSORS: 'smartlab_sensors_v1',
  DEVICES: 'smartlab_devices_v1',
  ALERTS: 'smartlab_alerts_v1',
  SETTINGS: 'smartlab_settings_v1',
  USER: 'smartlab_user_v1',
};

export const IoTProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load from local storage with initial fallback
  const [labs, setLabs] = useState<Lab[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LABS);
    return saved ? JSON.parse(saved) : INITIAL_LABS;
  });

  const [sensors, setSensors] = useState<Sensor[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SENSORS);
    return saved ? JSON.parse(saved) : INITIAL_SENSORS;
  });

  const [devices, setDevices] = useState<Device[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DEVICES);
    return saved ? JSON.parse(saved) : INITIAL_DEVICES;
  });

  const [alerts, setAlerts] = useState<Alert[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ALERTS);
    return saved ? JSON.parse(saved) : INITIAL_ALERTS;
  });

  const [settings, setSettings] = useState<SystemSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });

  const [hourlyData, setHourlyData] = useState<HourlyTelemetry[]>(INITIAL_HOURLY_DATA);
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [lastTickTime, setLastTickTime] = useState<Date>(new Date());
  const [activeFilterLab, setActiveFilterLab] = useState<string>('all');

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LABS, JSON.stringify(labs));
  }, [labs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SENSORS, JSON.stringify(sensors));
  }, [sensors]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DEVICES, JSON.stringify(devices));
  }, [devices]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(alerts));
  }, [alerts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
  }, [currentUser]);

  // Simulation tick loop
  useEffect(() => {
    if (!settings.demoMode || !isSimulating) return;

    const intervalMs = Math.max(1000, 3200 / settings.simulationSpeed);

    const timer = setInterval(() => {
      setLastTickTime(new Date());

      // 1. Recalculate devices power with small realistic fluctuations (±1.5%)
      setDevices(prevDevices => 
        prevDevices.map(dev => {
          if (dev.connectivity === 'offline' || dev.state === 'OFF') {
            return { ...dev, powerWatts: 0, lastCommunication: 'Just now' };
          }
          if (dev.state === 'STANDBY') {
            const standbyWatts = Math.round(dev.nominalWatts * 0.15 + (Math.random() * 10 - 5));
            return { ...dev, powerWatts: Math.max(5, standbyWatts), lastCommunication: 'Just now' };
          }
          // ON state fluctuation
          const jitterPercent = (Math.random() * 0.04) - 0.02; // -2% to +2%
          const updatedWatts = Math.round(dev.nominalWatts * (1 + jitterPercent));
          return { ...dev, powerWatts: updatedWatts, lastCommunication: 'Just now' };
        })
      );

      // 2. Update Sensors based on device states & environment
      setSensors(prevSensors => 
        prevSensors.map(sensor => {
          if (!sensor.isOnline) return sensor;

          if (sensor.type === 'smart_energy_meter') {
            // Aggregate power for that lab
            const labDevs = devices.filter(d => d.labId === sensor.labId && d.state !== 'OFF');
            const totalW = labDevs.reduce((acc, d) => acc + d.powerWatts, 0) + 1200; // 1200W baseline lighting & auxiliary
            const voltage = +(229 + Math.random() * 2).toFixed(1);
            const current = +(totalW / voltage).toFixed(1);

            const newHist = [...sensor.history.slice(-14), { time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }), value: totalW }];

            return {
              ...sensor,
              value: totalW,
              secondaryValue: voltage,
              secondaryUnit: `V (${current} A)`,
              lastUpdated: 'Just now',
              history: newHist,
            };
          }

          if (sensor.type === 'temp_humidity') {
            // slight temperature wave
            const delta = (Math.random() * 0.2 - 0.1);
            const newVal = +(sensor.value + delta).toFixed(1);
            return {
              ...sensor,
              value: Math.min(28, Math.max(18, newVal)),
              secondaryValue: +(Number(sensor.secondaryValue || 45) + (Math.random() * 0.4 - 0.2)).toFixed(1),
              lastUpdated: 'Just now',
            };
          }

          if (sensor.type === 'pir_motion') {
            const lab = labs.find(l => l.id === sensor.labId);
            const hasOccupants = (lab?.currentOccupancy || 0) > 0;
            // if occupants > 0, mostly 1 with occasional 0
            const motionVal = hasOccupants ? (Math.random() > 0.1 ? 1 : 0) : 0;
            return {
              ...sensor,
              value: motionVal,
              lastUpdated: 'Just now',
            };
          }

          if (sensor.type === 'air_quality') {
            const lab = labs.find(l => l.id === sensor.labId);
            const base = (lab?.currentOccupancy || 0) > 4 ? 55 : 42;
            const jitter = Math.floor(Math.random() * 6 - 3);
            return {
              ...sensor,
              value: Math.max(20, base + jitter),
              lastUpdated: 'Just now',
            };
          }

          return { ...sensor, lastUpdated: 'Just now' };
        })
      );

      // 3. Update Labs totals
      setLabs(prevLabs => 
        prevLabs.map(lab => {
          const labSensors = sensors.filter(s => s.labId === lab.id);
          const meter = labSensors.find(s => s.type === 'smart_energy_meter');
          const peopleCounter = labSensors.find(s => s.type === 'ir_people_counter');
          
          const currentWatts = meter ? meter.value : lab.totalPowerWatts;
          const currentOcc = peopleCounter ? peopleCounter.value : lab.currentOccupancy;
          
          let status: OccupancyStatus = 'Vacant';
          if (currentOcc > 0 && currentOcc < lab.maxOccupancy * 0.6) {
            status = 'Partially Occupied';
          } else if (currentOcc >= lab.maxOccupancy * 0.6) {
            status = 'Occupied';
          }

          // Count active alerts for this lab
          const labAlerts = alerts.filter(a => a.labId === lab.id && !a.resolved);

          return {
            ...lab,
            totalPowerWatts: currentWatts,
            currentOccupancy: currentOcc,
            occupancyStatus: status,
            alertCount: labAlerts.length,
          };
        })
      );

      // 4. Waste Detection Automation
      if (settings.autoDetectWaste) {
        // Check if any lab is vacant but has high-power equipment ON
        devices.forEach(dev => {
          const lab = labs.find(l => l.id === dev.labId);
          if (lab && lab.currentOccupancy === 0 && dev.state === 'ON' && dev.powerWatts > 800) {
            // Check if alert already exists
            const existing = alerts.find(a => a.deviceId === dev.id && a.type === 'vacant_waste' && !a.resolved);
            if (!existing) {
              const newAlert: Alert = {
                id: `alt-auto-${Date.now()}`,
                timestamp: new Date().toLocaleString(),
                labId: lab.id,
                labName: lab.name,
                deviceId: dev.id,
                deviceName: dev.name,
                type: 'vacant_waste',
                severity: 'warning',
                description: `Energy waste: "${dev.name}" draws ${(dev.powerWatts / 1000).toFixed(2)} kW while ${lab.name} is completely vacant.`,
                recommendedAction: 'Engage remote smart shutoff or alert lab safety technician.',
                acknowledged: false,
                resolved: false,
              };
              setAlerts(prev => [newAlert, ...prev]);
            }
          }
        })
      }

    }, intervalMs);

    return () => clearInterval(timer);
  }, [settings.demoMode, settings.simulationSpeed, isSimulating, devices, labs, sensors, alerts, settings.autoDetectWaste]);

  // Actions
  const toggleSimulation = () => {
    setIsSimulating(prev => !prev);
  };

  const setSimulationSpeed = (speed: number) => {
    setSettings(prev => ({ ...prev, simulationSpeed: speed }));
  };

  const toggleDeviceState = useCallback(async (deviceId: string, targetState: 'ON' | 'OFF'): Promise<boolean> => {
    // Return promise simulating physical relay handshake
    return new Promise(resolve => {
      setTimeout(() => {
        setDevices(prev => 
          prev.map(dev => {
            if (dev.id === deviceId) {
              const newWatts = targetState === 'OFF' ? 0 : dev.nominalWatts;
              return {
                ...dev,
                state: targetState,
                powerWatts: newWatts,
                lastCommunication: 'Just now (Command ACK)',
              };
            }
            return dev;
          })
        );
        resolve(true);
      }, 350);
    });
  }, []);

  const updateDeviceAutoShutoff = (deviceId: string, enabled: boolean, delay: number) => {
    setDevices(prev => 
      prev.map(d => d.id === deviceId ? { ...d, autoShutoffVacant: enabled, vacancyShutoffDelayMinutes: delay } : d)
    );
  };

  const updateSensorThresholds = (sensorId: string, thresholds: SensorThresholds) => {
    setSensors(prev => 
      prev.map(s => s.id === sensorId ? { ...s, thresholds } : s)
    );
  };

  const acknowledgeAlert = (alertId: string) => {
    setAlerts(prev => 
      prev.map(a => a.id === alertId ? { ...a, acknowledged: true } : a)
    );
  };

  const resolveAlert = (alertId: string) => {
    setAlerts(prev => 
      prev.map(a => a.id === alertId ? { ...a, resolved: true, acknowledged: true } : a)
    );
  };

  const deleteAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(a => a.id !== alertId));
  };

  const clearAllAlerts = () => {
    setAlerts([]);
  };

  const updateLab = (updatedLab: Lab) => {
    setLabs(prev => prev.map(l => l.id === updatedLab.id ? updatedLab : l));
  };

  const addLab = (newLabData: Omit<Lab, 'id' | 'totalPowerWatts' | 'dailyKwh' | 'alertCount'>) => {
    const id = `lab-${Date.now().toString(36)}`;
    const newLab: Lab = {
      ...newLabData,
      id,
      totalPowerWatts: 2400,
      dailyKwh: 18.5,
      alertCount: 0,
    };
    setLabs(prev => [...prev, newLab]);
  };

  const deleteLab = (labId: string) => {
    setLabs(prev => prev.filter(l => l.id !== labId));
    setDevices(prev => prev.filter(d => d.labId !== labId));
    setSensors(prev => prev.filter(s => s.labId !== labId));
  };

  const updateSettings = (newSettings: Partial<SystemSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const switchUserRole = (role: UserRole) => {
    setCurrentUser(prev => ({
      ...prev,
      role,
      name: role === 'admin' ? 'Dr. Elena Vance (Admin)' : role === 'facility_manager' ? 'Marcus Brody (Facility Ops)' : 'Sarah Lin (Researcher)',
    }));
  };

  const adjustOccupancy = (labId: string, newCount: number) => {
    const clamped = Math.max(0, newCount);
    // Update people counter sensor
    setSensors(prev => 
      prev.map(s => {
        if (s.labId === labId && s.type === 'ir_people_counter') {
          return { ...s, value: clamped, lastUpdated: 'Manual override' };
        }
        return s;
      })
    );
    // Update lab
    setLabs(prev => 
      prev.map(l => {
        if (l.id === labId) {
          let status: OccupancyStatus = 'Vacant';
          if (clamped > 0 && clamped < l.maxOccupancy * 0.6) status = 'Partially Occupied';
          else if (clamped >= l.maxOccupancy * 0.6) status = 'Occupied';
          return { ...l, currentOccupancy: clamped, occupancyStatus: status };
        }
        return l;
      })
    );
  };

  const triggerSimulationScenario = (scenario: 'vacant_waste' | 'temp_spike' | 'sensor_disconnect' | 'reset') => {
    if (scenario === 'reset') {
      setLabs(INITIAL_LABS);
      setSensors(INITIAL_SENSORS);
      setDevices(INITIAL_DEVICES);
      setAlerts(INITIAL_ALERTS);
      return;
    }

    if (scenario === 'vacant_waste') {
      // Empty Lab A and turn on all heavy instruments
      adjustOccupancy('lab-a102', 0);
      setDevices(prev => 
        prev.map(d => d.labId === 'lab-a102' ? { ...d, state: 'ON', powerWatts: d.nominalWatts } : d)
      );
      const alert: Alert = {
        id: `alt-sim-${Date.now()}`,
        timestamp: new Date().toLocaleString(),
        labId: 'lab-a102',
        labName: 'Bio-Genomics & Molecular Lab',
        type: 'vacant_waste',
        severity: 'critical',
        description: 'Simulated Scenario: Lab A-102 evacuated, but Centrifuge and Fume Hood continue drawing 3.8 kW.',
        recommendedAction: 'Engage SmartRelay Group Shutoff to save an estimated $18.40 overnight.',
        acknowledged: false,
        resolved: false,
      };
      setAlerts(prev => [alert, ...prev]);
    }

    if (scenario === 'temp_spike') {
      setSensors(prev => 
        prev.map(s => {
          if (s.id === 'sns-a102-env') {
            return { ...s, value: 29.8, lastUpdated: 'Spike Anomaly!' };
          }
          return s;
        })
      );
      const alert: Alert = {
        id: `alt-temp-${Date.now()}`,
        timestamp: new Date().toLocaleString(),
        labId: 'lab-a102',
        labName: 'Bio-Genomics & Molecular Lab',
        sensorId: 'sns-a102-env',
        sensorName: 'BME280 Precision Climate Probe',
        type: 'abnormal_temp',
        severity: 'critical',
        description: 'Ambient temperature reached 29.8°C (Threshold: 24.5°C). Critical reagent preservation risk.',
        recommendedAction: 'Inspect VAV damper control and chilled water loop valve.',
        acknowledged: false,
        resolved: false,
      };
      setAlerts(prev => [alert, ...prev]);
    }

    if (scenario === 'sensor_disconnect') {
      setSensors(prev => 
        prev.map(s => s.id === 'sns-b205-meter' ? { ...s, isOnline: false, lastUpdated: 'Offline' } : s)
      );
      const alert: Alert = {
        id: `alt-disc-${Date.now()}`,
        timestamp: new Date().toLocaleString(),
        labId: 'lab-b205',
        labName: 'Nanotech & Materials Synthesis',
        sensorId: 'sns-b205-meter',
        sensorName: 'Janitza UMG Smart Power Analyzer B',
        type: 'sensor_offline',
        severity: 'warning',
        description: 'Sensor offline: Modbus RS485 loop heartbeat missing for 15 minutes.',
        recommendedAction: 'Verify RS485 gateway power and line termination resistor.',
        acknowledged: false,
        resolved: false,
      };
      setAlerts(prev => [alert, ...prev]);
    }
  };

  // CSV Exporter
  const exportDataCSV = (type: 'energy' | 'occupancy' | 'sensors' | 'all') => {
    let csvContent = 'data:text/csv;charset=utf-8,';
    const nowIso = new Date().toISOString();

    if (type === 'energy' || type === 'all') {
      csvContent += '--- HOURLY ENERGY TELEMETRY ---\n';
      csvContent += 'Time,Power_kW,Occupancy,BaseLoad_kW,Cost_USD,OccupiedPower_kW,VacantPower_kW\n';
      hourlyData.forEach(row => {
        csvContent += `${row.time},${row.powerKw},${row.occupancy},${row.baseLoadKw},${row.cost},${row.occupiedPowerKw},${row.vacantPowerKw}\n`;
      });
      csvContent += '\n--- CONNECTED DEVICES POWER ---\n';
      csvContent += 'DeviceID,Name,LabID,Zone,Category,State,PowerWatts,DailyKwh,Connectivity\n';
      devices.forEach(d => {
        csvContent += `${d.id},"${d.name}",${d.labId},"${d.zone}",${d.category},${d.state},${d.powerWatts},${d.dailyKwh},${d.connectivity}\n`;
      });
    }

    if (type === 'sensors' || type === 'all') {
      csvContent += '\n--- SENSOR READINGS TELEMETRY ---\n';
      csvContent += 'SensorID,Name,Type,LabID,Zone,Value,Unit,SecondaryValue,IsOnline,LastUpdated\n';
      sensors.forEach(s => {
        csvContent += `${s.id},"${s.name}",${s.type},${s.labId},"${s.zone}",${s.value},"${s.unit}","${s.secondaryValue || ''}",${s.isOnline},"${s.lastUpdated}"\n`;
      });
    }

    if (type === 'occupancy' || type === 'all') {
      csvContent += '\n--- LABORATORY OCCUPANCY STATUS ---\n';
      csvContent += 'LabID,Name,Building,MaxOccupancy,CurrentOccupancy,Status,TotalPowerWatts,DailyKwh\n';
      labs.forEach(l => {
        csvContent += `${l.id},"${l.name}","${l.building}",${l.maxOccupancy},${l.currentOccupancy},${l.occupancyStatus},${l.totalPowerWatts},${l.dailyKwh}\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `smartlab_telemetry_export_${nowIso.slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Computations
  const totalCurrentWatts = useMemo(() => {
    return labs.reduce((sum, l) => sum + (l.totalPowerWatts || 0), 0);
  }, [labs]);

  const totalDailyKwh = useMemo(() => {
    return +(labs.reduce((sum, l) => sum + (l.dailyKwh || 0), 0)).toFixed(1);
  }, [labs]);

  const totalOccupancy = useMemo(() => {
    return labs.reduce((sum, l) => sum + (l.currentOccupancy || 0), 0);
  }, [labs]);

  const overallOccupancyStatus = useMemo((): OccupancyStatus => {
    const totalMax = labs.reduce((sum, l) => sum + l.maxOccupancy, 0);
    if (totalOccupancy === 0) return 'Vacant';
    if (totalOccupancy < totalMax * 0.5) return 'Partially Occupied';
    return 'Occupied';
  }, [labs, totalOccupancy]);

  const estimatedDailyCost = useMemo(() => {
    return +(totalDailyKwh * settings.electricityTariff).toFixed(2);
  }, [totalDailyKwh, settings.electricityTariff]);

  const unresolvedAlerts = useMemo(() => {
    return alerts.filter(a => !a.resolved);
  }, [alerts]);

  const activeAlertCount = unresolvedAlerts.length;

  const energyEfficiencyScore = useMemo(() => {
    // Score based on vacant waste and alerts
    // Vacant power ratio: how much power is drawn while rooms are vacant
    const vacantLabs = labs.filter(l => l.currentOccupancy === 0);
    const vacantPowerTotal = vacantLabs.reduce((sum, l) => sum + l.totalPowerWatts, 0);
    const vacantRatio = totalCurrentWatts > 0 ? vacantPowerTotal / totalCurrentWatts : 0;
    
    let base = 96;
    base -= Math.round(vacantRatio * 30); // penalty for high vacant draw
    base -= activeAlertCount * 4; // penalty for unresolved anomalies
    return Math.max(25, Math.min(99, base));
  }, [labs, totalCurrentWatts, activeAlertCount]);

  const avgTemp = useMemo(() => {
    const tempSensors = sensors.filter(s => s.type === 'temp_humidity' && s.isOnline);
    if (tempSensors.length === 0) return 21.0;
    const sum = tempSensors.reduce((acc, s) => acc + s.value, 0);
    return +(sum / tempSensors.length).toFixed(1);
  }, [sensors]);

  const avgHumidity = useMemo(() => {
    const tempSensors = sensors.filter(s => s.type === 'temp_humidity' && s.isOnline && s.secondaryValue);
    if (tempSensors.length === 0) return 45.0;
    const sum = tempSensors.reduce((acc, s) => acc + (s.secondaryValue || 45), 0);
    return Math.round(sum / tempSensors.length);
  }, [sensors]);

  const totalDevicesOnline = useMemo(() => {
    return devices.filter(d => d.connectivity === 'online').length;
  }, [devices]);

  const totalSensorsOnline = useMemo(() => {
    return sensors.filter(s => s.isOnline).length;
  }, [sensors]);

  return (
    <IoTContext.Provider
      value={{
        labs,
        sensors,
        devices,
        alerts,
        settings,
        hourlyData,
        currentUser,
        isSimulating,
        lastTickTime,
        activeFilterLab,
        setActiveFilterLab,
        toggleSimulation,
        setSimulationSpeed,
        toggleDeviceState,
        updateDeviceAutoShutoff,
        updateSensorThresholds,
        acknowledgeAlert,
        resolveAlert,
        deleteAlert,
        clearAllAlerts,
        updateLab,
        addLab,
        deleteLab,
        updateSettings,
        switchUserRole,
        adjustOccupancy,
        triggerSimulationScenario,
        exportDataCSV,
        totalCurrentWatts,
        totalDailyKwh,
        totalOccupancy,
        overallOccupancyStatus,
        estimatedDailyCost,
        energyEfficiencyScore,
        activeAlertCount,
        unresolvedAlerts,
        avgTemp,
        avgHumidity,
        totalDevicesOnline,
        totalSensorsOnline,
      }}
    >
      {children}
    </IoTContext.Provider>
  );
};

export const useIoT = () => {
  const context = useContext(IoTContext);
  if (!context) {
    throw new Error('useIoT must be used within an IoTProvider');
  }
  return context;
};
