import React from 'react';
import { 
  LayoutDashboard, 
  Radio, 
  Users, 
  TrendingUp, 
  Cpu, 
  Power, 
  Bell, 
  Building2, 
  FileText, 
  Settings, 
  ChevronLeft, 
  ChevronRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { useIoT } from '../../context/IoTContext';

export type NavPage = 
  | 'dashboard' 
  | 'live' 
  | 'occupancy' 
  | 'analytics' 
  | 'sensors' 
  | 'devices' 
  | 'alerts' 
  | 'labs' 
  | 'reports' 
  | 'settings';

interface SidebarProps {
  currentPage: NavPage;
  onNavigate: (page: NavPage) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  isCollapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
}) => {
  const { activeAlertCount, settings } = useIoT();

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'live', label: 'Live Monitoring', icon: Radio, badge: 'LIVE' },
    { id: 'occupancy', label: 'Occupancy', icon: Users },
    { id: 'analytics', label: 'Energy Analytics', icon: TrendingUp },
    { id: 'sensors', label: 'Sensors', icon: Cpu },
    { id: 'devices', label: 'Smart Devices', icon: Power },
    { id: 'alerts', label: 'Alerts', icon: Bell, count: activeAlertCount },
    { id: 'labs', label: 'Laboratories', icon: Building2 },
    { id: 'reports', label: 'Reports & Export', icon: FileText },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleSelect = (id: NavPage) => {
    onNavigate(id);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-xs"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 bg-[#0B0F19] border-r border-slate-800/80 flex flex-col transition-all duration-300 ease-in-out
          ${isCollapsed ? 'w-20' : 'w-64'}
          ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800/80 bg-slate-950/40">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 via-sky-500 to-emerald-400 p-0.5 shadow-lg shadow-cyan-500/20 flex-shrink-0 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Zap className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            {!isCollapsed && (
              <div className="flex flex-col min-w-0">
                <span className="font-bold text-slate-100 text-base tracking-tight truncate flex items-center gap-1.5">
                  SmartLab
                  <span className="text-[10px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-1.5 py-0.2 rounded">
                    IoT
                  </span>
                </span>
                <span className="text-[10px] text-slate-400 font-medium truncate tracking-wide">
                  Intelligent Energy
                </span>
              </div>
            )}
          </div>

          {/* Desktop Collapse Toggle */}
          <button
            onClick={onToggleCollapse}
            className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition-colors"
            title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id as NavPage)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition-all group relative ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-600/20 to-sky-600/10 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-950'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
                title={isCollapsed ? item.label : undefined}
              >
                <Icon className={`w-5 h-5 flex-shrink-0 transition-colors ${isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-slate-200'}`} />

                {!isCollapsed && (
                  <span className="truncate flex-1 text-left">{item.label}</span>
                )}

                {/* Badge or Count */}
                {!isCollapsed && item.count !== undefined && item.count > 0 && (
                  <span className="px-1.5 py-0.5 text-xs font-bold rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                    {item.count}
                  </span>
                )}

                {!isCollapsed && item.badge && (
                  <span className="px-1.5 py-0.5 text-[10px] font-bold rounded tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse">
                    {item.badge}
                  </span>
                )}

                {/* Collapsed dot for alerts */}
                {isCollapsed && item.count !== undefined && item.count > 0 && (
                  <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-slate-900" />
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom System Status */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/40">
          {!isCollapsed ? (
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 text-xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-slate-400 font-medium">Gateway Link</span>
                <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  {settings.demoMode ? 'SIMULATED' : 'MQTT 8883'}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 flex items-center justify-between">
                <span>Privacy Mode:</span>
                <span className="text-cyan-400 flex items-center gap-1 font-mono-val text-[10px]">
                  <ShieldCheck className="w-3 h-3" /> Anonymous
                </span>
              </div>
            </div>
          ) : (
            <div className="flex justify-center" title="IoT Network Active">
              <div className="w-3 h-3 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20"></div>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
