import React, { useState, useEffect, useRef } from 'react';
import { 
  Menu, 
  Bell, 
  Download, 
  Clock, 
  ChevronDown, 
  Shield, 
  UserCheck, 
  AlertTriangle,
  Building2,
  ExternalLink,
  CheckCircle2
} from 'lucide-react';
import { useIoT } from '../../context/IoTContext';
import { NavPage } from './Sidebar';
import { UserRole } from '../../types';

interface TopHeaderProps {
  currentPage: NavPage;
  onNavigate: (page: NavPage) => void;
  onOpenMobile: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentPage,
  onNavigate,
  onOpenMobile,
}) => {
  const { 
    labs, 
    activeFilterLab, 
    setActiveFilterLab, 
    currentUser, 
    switchUserRole,
    unresolvedAlerts,
    acknowledgeAlert,
    exportDataCSV,
    settings,
  } = useIoT();

  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [showAlertsDropdown, setShowAlertsDropdown] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);

  const alertsRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Live ticking clock
  useEffect(() => {
    const clock = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(clock);
  }, []);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (alertsRef.current && !alertsRef.current.contains(e.target as Node)) {
        setShowAlertsDropdown(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setShowProfileDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const pageTitles: Record<NavPage, { title: string; subtitle: string }> = {
    dashboard: { title: 'Dashboard Overview', subtitle: 'Real-time telemetry, energy intensity, and occupancy state' },
    live: { title: 'Live Spatial Monitoring', subtitle: 'Interactive 2D lab floorplan & real-time sensor array' },
    occupancy: { title: 'Occupancy Analytics', subtitle: 'Utilization rates, vacancy delay logic, and privacy-preserving metrics' },
    analytics: { title: 'Energy Analytics & Tariffs', subtitle: 'Base-load profiling, peak demand, and cost optimizations' },
    sensors: { title: 'IoT Sensor Network', subtitle: 'PIR, IR people counters, sub-meters, and environmental probes' },
    devices: { title: 'Smart Equipment & Relays', subtitle: 'Connected laboratory loads, auto-shutoff rules, and manual controls' },
    alerts: { title: 'System Alerts & Warnings', subtitle: 'Automated anomaly detection, threshold breaches, and audit logs' },
    labs: { title: 'Laboratories & Facilities', subtitle: 'Zone management, occupancy limits, and performance comparison' },
    reports: { title: 'Reports & Telemetry Export', subtitle: 'Comprehensive audit reports and CSV data export' },
    settings: { title: 'System Settings & Integration', subtitle: 'Electricity tariffs, MQTT/REST API bridge, and hardware mode' },
  };

  const formattedDate = currentTime.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  const formattedTime = currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });

  return (
    <header className="h-16 bg-[#0B0F19]/90 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-30 px-4 md:px-6 flex items-center justify-between">
      {/* Left Title & Mobile Menu Button */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobile}
          className="p-2 -ml-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-base md:text-lg font-bold text-white tracking-tight">
              {pageTitles[currentPage]?.title || 'SmartLab Monitor'}
            </h1>
            <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800/60">
              v2.4
            </span>
          </div>
          <p className="text-xs text-slate-400 hidden md:block">
            {pageTitles[currentPage]?.subtitle || 'Intelligent Energy. Smarter Spaces.'}
          </p>
        </div>
      </div>

      {/* Right Quick Controls */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Lab Filter Selector */}
        <div className="relative hidden sm:block">
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 rounded-lg px-2.5 py-1.5 text-xs text-slate-200">
            <Building2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
            <select
              value={activeFilterLab}
              onChange={(e) => setActiveFilterLab(e.target.value)}
              className="bg-transparent border-none text-slate-200 text-xs focus:ring-0 cursor-pointer pr-4 font-medium"
            >
              <option value="all" className="bg-slate-900 text-slate-100">All Laboratories ({labs.length})</option>
              {labs.map(lab => (
                <option key={lab.id} value={lab.id} className="bg-slate-900 text-slate-100">
                  {lab.code} - {lab.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Live Date/Time Ticker */}
        <div className="hidden xl:flex items-center gap-2 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg text-xs font-mono-val text-slate-300">
          <Clock className="w-3.5 h-3.5 text-cyan-400" />
          <span>{formattedDate}</span>
          <span className="text-slate-500">|</span>
          <span className="text-cyan-300 font-bold">{formattedTime}</span>
        </div>

        {/* Quick CSV Export */}
        <button
          onClick={() => exportDataCSV('all')}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 border border-slate-700 rounded-lg text-xs font-medium transition-colors"
          title="Export current telemetry snapshot to CSV"
        >
          <Download className="w-3.5 h-3.5 text-cyan-400" />
          <span>CSV</span>
        </button>

        {/* Alerts Bell Dropdown */}
        <div className="relative" ref={alertsRef}>
          <button
            onClick={() => setShowAlertsDropdown(prev => !prev)}
            className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors relative"
            title="Active Notifications"
            aria-label="Alerts"
          >
            <Bell className="w-4 h-4" />
            {unresolvedAlerts.length > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] flex items-center justify-center text-[10px] font-bold rounded-full bg-rose-500 text-white px-1 shadow-md shadow-rose-950 animate-pulse">
                {unresolvedAlerts.length}
              </span>
            )}
          </button>

          {showAlertsDropdown && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 overflow-hidden text-slate-200">
              <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span className="font-semibold text-xs text-white uppercase tracking-wider">
                    Unresolved Alerts ({unresolvedAlerts.length})
                  </span>
                </div>
                <button
                  onClick={() => {
                    setShowAlertsDropdown(false);
                    onNavigate('alerts');
                  }}
                  className="text-cyan-400 hover:text-cyan-300 text-xs font-medium flex items-center gap-1"
                >
                  View All <ExternalLink className="w-3 h-3" />
                </button>
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/60">
                {unresolvedAlerts.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-70" />
                    All laboratory spaces operating within safe nominal parameters.
                  </div>
                ) : (
                  unresolvedAlerts.map(alert => (
                    <div key={alert.id} className="p-3 hover:bg-slate-800/40 transition-colors text-xs">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                          alert.severity === 'critical' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                          alert.severity === 'warning' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                          'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                        }`}>
                          {alert.severity}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono-val">{alert.timestamp.slice(11)}</span>
                      </div>
                      <p className="font-medium text-slate-200 mb-1">{alert.description}</p>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                        <span className="text-cyan-400 truncate max-w-[180px]">{alert.labName}</span>
                        {!alert.acknowledged && (
                          <button
                            onClick={() => acknowledgeAlert(alert.id)}
                            className="text-xs text-slate-300 hover:text-white underline underline-offset-2"
                          >
                            Ack
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Profile & Role Switcher */}
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setShowProfileDropdown(prev => !prev)}
            className="flex items-center gap-2 p-1 pl-2 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg transition-colors"
          >
            <div className="text-right hidden md:block">
              <div className="text-xs font-semibold text-slate-200 truncate max-w-[130px] leading-tight">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-cyan-400 font-medium capitalize flex items-center justify-end gap-1">
                <Shield className="w-2.5 h-2.5" />
                {currentUser.role.replace('_', ' ')}
              </div>
            </div>
            <img 
              src={currentUser.avatar} 
              alt={currentUser.name}
              className="w-8 h-8 rounded-lg object-cover border border-cyan-500/30"
            />
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 mr-1 hidden sm:block" />
          </button>

          {showProfileDropdown && (
            <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 p-3 text-slate-200">
              <div className="pb-3 mb-2 border-b border-slate-800">
                <p className="text-xs text-slate-400 font-medium">Logged in as</p>
                <p className="text-sm font-bold text-white">{currentUser.name}</p>
                <p className="text-xs text-slate-400 truncate">{currentUser.email}</p>
              </div>

              <div className="space-y-1 mb-3">
                <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-1">
                  Switch Active Role (RBAC):
                </p>
                {(['admin', 'facility_manager', 'researcher'] as UserRole[]).map(role => (
                  <button
                    key={role}
                    onClick={() => {
                      switchUserRole(role);
                      setShowProfileDropdown(false);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      currentUser.role === role
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span className="capitalize">{role.replace('_', ' ')}</span>
                    {currentUser.role === role && <UserCheck className="w-3.5 h-3.5 text-cyan-400" />}
                  </button>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                <span>Mode:</span>
                <span className="text-cyan-400 font-medium">
                  {settings.demoMode ? 'Simulation Enabled' : 'Live Gateway'}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
