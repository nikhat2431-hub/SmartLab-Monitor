import React from 'react';
import { useIoT } from '../../context/IoTContext';
import { Play, Pause, Zap, Flame, WifiOff, RotateCcw, Activity } from 'lucide-react';

export const DemoBanner: React.FC = () => {
  const { 
    settings, 
    isSimulating, 
    toggleSimulation, 
    setSimulationSpeed, 
    triggerSimulationScenario,
    lastTickTime 
  } = useIoT();

  if (!settings.demoMode) {
    return (
      <div className="bg-emerald-950/40 border-b border-emerald-500/30 px-4 py-2 text-xs flex flex-wrap items-center justify-between text-emerald-300">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="font-semibold tracking-wide uppercase">Hardware Live Mode Active</span>
          <span className="text-slate-400">| Listening on MQTT: {settings.mqttBrokerUrl}:{settings.mqttPort}</span>
        </div>
        <div className="text-slate-400 text-xs">
          Topic: <code className="bg-slate-900 px-1.5 py-0.5 rounded text-emerald-400">{settings.mqttTopicRoot}/#</code>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-sky-950/60 via-slate-900/90 to-cyan-950/50 border-b border-cyan-800/40 px-3 md:px-5 py-2 text-xs">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Left status */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 bg-cyan-950/80 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-md font-medium">
            <Activity className={`w-3.5 h-3.5 ${isSimulating ? 'animate-pulse text-cyan-400' : 'text-slate-500'}`} />
            <span>SIMULATION ENGINE</span>
            <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-1 rounded">SYNTHETIC</span>
          </div>
          <span className="text-slate-400 hidden sm:inline">
            Physics engine running • Last tick: <span className="text-slate-200 font-mono-val">{lastTickTime.toLocaleTimeString()}</span>
          </span>
        </div>

        {/* Action controls */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Pause / Play */}
          <button
            onClick={toggleSimulation}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded font-medium transition-colors ${
              isSimulating 
                ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30' 
                : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/30'
            }`}
            title={isSimulating ? 'Pause simulation tick' : 'Resume simulation'}
          >
            {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isSimulating ? 'Pause' : 'Resume'}</span>
          </button>

          {/* Speed selector */}
          <div className="flex items-center bg-slate-900 border border-slate-700/80 rounded px-1.5 py-0.5 text-slate-300">
            <span className="text-[11px] text-slate-400 mr-1.5">Speed:</span>
            {[1, 2, 5].map(speed => (
              <button
                key={speed}
                onClick={() => setSimulationSpeed(speed)}
                className={`px-1.5 py-0.5 text-[11px] rounded transition-colors ${
                  settings.simulationSpeed === speed
                    ? 'bg-cyan-500/30 text-cyan-300 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {speed}x
              </button>
            ))}
          </div>

          {/* Anomaly triggers for demo testing */}
          <div className="hidden lg:flex items-center gap-1.5 pl-2 border-l border-slate-700">
            <span className="text-[11px] text-slate-400">Inject Event:</span>
            <button
              onClick={() => triggerSimulationScenario('vacant_waste')}
              className="flex items-center gap-1 px-2 py-0.5 bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 border border-rose-500/30 rounded text-[11px] transition-colors"
              title="Evacuate Lab A while leaving heavy equipment running"
            >
              <Zap className="w-3 h-3 text-rose-400" />
              <span>Vacant Waste</span>
            </button>
            <button
              onClick={() => triggerSimulationScenario('temp_spike')}
              className="flex items-center gap-1 px-2 py-0.5 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30 rounded text-[11px] transition-colors"
              title="Simulate HVAC failure & ambient temperature spike to 29.8°C"
            >
              <Flame className="w-3 h-3 text-amber-400" />
              <span>Temp Spike</span>
            </button>
            <button
              onClick={() => triggerSimulationScenario('sensor_disconnect')}
              className="flex items-center gap-1 px-2 py-0.5 bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-600 rounded text-[11px] transition-colors"
              title="Drop connection to Lab B smart meter"
            >
              <WifiOff className="w-3 h-3 text-slate-400" />
              <span>Sensor Drop</span>
            </button>
            <button
              onClick={() => triggerSimulationScenario('reset')}
              className="flex items-center gap-1 px-1.5 py-0.5 text-slate-400 hover:text-white text-[11px] transition-colors"
              title="Reset simulation to default clean baseline"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
