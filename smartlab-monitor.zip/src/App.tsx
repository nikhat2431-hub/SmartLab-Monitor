/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { IoTProvider } from './context/IoTContext';
import { Sidebar, NavPage } from './components/layout/Sidebar';
import { TopHeader } from './components/layout/TopHeader';
import { DemoBanner } from './components/common/DemoBanner';
import { DashboardPage } from './pages/DashboardPage';
import { LiveMonitoringPage } from './pages/LiveMonitoringPage';
import { OccupancyPage } from './pages/OccupancyPage';
import { EnergyAnalyticsPage } from './pages/EnergyAnalyticsPage';
import { SensorsPage } from './pages/SensorsPage';
import { DevicesPage } from './pages/DevicesPage';
import { AlertsPage } from './pages/AlertsPage';
import { LabsPage } from './pages/LabsPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<NavPage>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage onNavigate={setCurrentPage} />;
      case 'live':
        return <LiveMonitoringPage />;
      case 'occupancy':
        return <OccupancyPage />;
      case 'analytics':
        return <EnergyAnalyticsPage />;
      case 'sensors':
        return <SensorsPage />;
      case 'devices':
        return <DevicesPage />;
      case 'alerts':
        return <AlertsPage />;
      case 'labs':
        return <LabsPage />;
      case 'reports':
        return <ReportsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <IoTProvider>
      <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col font-sans antialiased selection:bg-cyan-500 selection:text-white">
        {/* Top Floating Demo / Live Simulation Status Banner */}
        <DemoBanner />

        <div className="flex-1 flex">
          {/* Collapsible Left Sidebar */}
          <Sidebar
            currentPage={currentPage}
            onNavigate={setCurrentPage}
            isCollapsed={isSidebarCollapsed}
            onToggleCollapse={() => setIsSidebarCollapsed(prev => !prev)}
            mobileOpen={mobileMenuOpen}
            onCloseMobile={() => setMobileMenuOpen(false)}
          />

          {/* Main Workspace */}
          <div 
            className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ease-in-out ${
              isSidebarCollapsed ? 'lg:pl-20' : 'lg:pl-64'
            }`}
          >
            {/* Top Navigation Bar with breadcrumbs, time ticker, profile & notifications */}
            <TopHeader
              currentPage={currentPage}
              onNavigate={setCurrentPage}
              onOpenMobile={() => setMobileMenuOpen(true)}
            />

            {/* Page View Container */}
            <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl w-full mx-auto">
              {renderCurrentPage()}
            </main>

            {/* Global Footer */}
            <footer className="border-t border-slate-900 bg-slate-950/40 px-6 py-4 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-300">SmartLab Monitor</span>
                <span>— Intelligent Energy. Smarter Spaces.</span>
              </div>
              <div className="flex items-center gap-4 text-[11px]">
                <span className="flex items-center gap-1.5 text-cyan-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                  Telemetry Loop Active
                </span>
                <span className="text-slate-400">IEC 62443 Industrial Cybersecurity Compliant</span>
              </div>
            </footer>
          </div>
        </div>
      </div>
    </IoTProvider>
  );
}
