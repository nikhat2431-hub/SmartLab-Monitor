import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  Users, 
  ShieldCheck, 
  Clock, 
  AlertTriangle, 
  Sliders, 
  UserPlus, 
  UserMinus, 
  TrendingUp, 
  Zap, 
  CheckCircle2, 
  Info,
  Calendar,
  RotateCcw
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  Legend 
} from 'recharts';

export const OccupancyPage: React.FC = () => {
  const { 
    labs, 
    sensors, 
    devices, 
    hourlyData, 
    totalOccupancy, 
    adjustOccupancy, 
    currentUser,
    settings,
    updateSettings 
  } = useIoT();

  const [adjustLabId, setAdjustLabId] = useState<string | null>(null);
  const [manualCount, setManualCount] = useState<number>(0);
  const [selectedLabFilter, setSelectedLabFilter] = useState<string>('all');

  const filteredLabs = selectedLabFilter === 'all' 
    ? labs 
    : labs.filter(l => l.id === selectedLabFilter);

  // Detect labs that are vacant but have high active power (Energy waste during vacant period)
  const vacantWasteLabs = labs.filter(l => {
    if (l.currentOccupancy !== 0) return false;
    const labDevs = devices.filter(d => d.labId === l.id && d.state === 'ON' && d.powerWatts > 500);
    return labDevs.length > 0;
  });

  const handleOpenAdjust = (labId: string, current: number) => {
    setAdjustLabId(labId);
    setManualCount(current);
  };

  const handleSaveAdjust = () => {
    if (adjustLabId) {
      adjustOccupancy(adjustLabId, manualCount);
      setAdjustLabId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Privacy Notice Banner */}
      <div className="bg-gradient-to-r from-cyan-950/40 via-slate-900 to-slate-900 border border-cyan-800/40 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex-shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Privacy-Preserving Occupancy Infrastructure
              <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded font-mono-val font-semibold">
                NO CAMERAS / NO BIOMETRICS
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              SmartLab relies exclusively on non-invasive directional IR beam counters and ceiling PIR micro-motion sensors. Identity and facial surveillance are strictly prohibited.
            </p>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block mb-1">
            Total Present Occupants
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-mono-val">{totalOccupancy}</span>
            <span className="text-xs text-slate-400">across 4 labs</span>
          </div>
          <span className="text-xs text-emerald-400 mt-2 block font-medium">
            38% campus capacity utilized
          </span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block mb-1">
            Peak Occupancy Window
          </span>
          <div className="text-lg font-bold text-white font-mono-val mt-1">10:00 - 11:30 AM</div>
          <span className="text-xs text-slate-400 mt-1 block">
            Secondary peak at 14:00 (18 persons)
          </span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block mb-1">
            Avg Occupancy Duration
          </span>
          <div className="text-lg font-bold text-white font-mono-val mt-1">3 hrs 15 mins</div>
          <span className="text-xs text-cyan-400 mt-1 block">
            Per active research session
          </span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block mb-1">
            Vacancy Delay Buffer
          </span>
          <div className="text-lg font-bold text-cyan-400 font-mono-val mt-1">
            {settings.vacancyDelayMinutes} Minutes
          </div>
          <span className="text-xs text-slate-400 mt-1 block">
            Before auto-triggering idle setback
          </span>
        </div>
      </div>

      {/* Vacancy Energy Wastage Alert Box (If any lab is vacant with equipment running) */}
      {vacantWasteLabs.length > 0 && (
        <div className="bg-rose-950/30 border border-rose-500/40 rounded-2xl p-5 shadow-lg">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-2 text-rose-400">
              <AlertTriangle className="w-5 h-5 flex-shrink-0" />
              <h4 className="text-sm font-bold text-white">
                Energy Waste Detected: Powered Equipment in Vacant Rooms ({vacantWasteLabs.length})
              </h4>
            </div>
            <span className="text-[10px] bg-rose-500/20 text-rose-300 font-bold px-2 py-0.5 rounded uppercase">
              Action Required
            </span>
          </div>

          <div className="space-y-2">
            {vacantWasteLabs.map(lab => {
              const activeDevs = devices.filter(d => d.labId === lab.id && d.state === 'ON');
              const wasteKw = (activeDevs.reduce((a, b) => a + b.powerWatts, 0) / 1000).toFixed(2);
              const estWasteCostPerHour = (Number(wasteKw) * settings.electricityTariff).toFixed(2);

              return (
                <div key={lab.id} className="bg-slate-950/80 p-3 rounded-xl border border-rose-900/40 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="font-bold text-rose-300">{lab.name} ({lab.code})</span>
                    <p className="text-slate-400 mt-0.5">
                      Room is currently <strong>VACANT (0 occupants)</strong>, but {activeDevs.length} device(s) are actively drawing <strong className="text-rose-400 font-mono-val">{wasteKw} kW</strong> ({settings.currencySymbol}{estWasteCostPerHour}/hr waste).
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">
                      Devices: {activeDevs.map(d => d.name.split(' ')[0]).join(', ')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Hourly Occupancy vs Energy Chart */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-cyan-400" />
              Occupancy vs Power Demand Correlation
            </h3>
            <p className="text-xs text-slate-400">
              Correlating people density (green bars) with occupied vs vacant power consumption (lines)
            </p>
          </div>
          <div className="text-xs text-slate-400 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            Base-load threshold: <span className="text-cyan-400 font-mono-val font-bold">6.5 kW</span>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 11 }} />
              <YAxis yAxisId="left" stroke="#64748b" tick={{ fontSize: 11 }} unit=" ppl" />
              <YAxis yAxisId="right" orientation="right" stroke="#06b6d4" tick={{ fontSize: 11 }} unit=" kW" />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
              <Bar yAxisId="left" dataKey="occupancy" name="Laboratory Occupants" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="powerKw" name="Total Power (kW)" stroke="#06b6d4" strokeWidth={2.5} dot={false} />
              <Line yAxisId="right" type="monotone" dataKey="vacantPowerKw" name="Unoccupied Base Load (kW)" stroke="#f43f5e" strokeDasharray="4 4" strokeWidth={2} dot={false} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Lab Breakdown Table with Manual Adjustments */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sliders className="w-5 h-5 text-cyan-400" />
              Zone-by-Zone Occupancy & Detection Methods
            </h3>
            <p className="text-xs text-slate-400">
              Real-time headcount, sensor telemetry method, and manual override controls
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Filter Lab:</span>
            <select
              value={selectedLabFilter}
              onChange={(e) => setSelectedLabFilter(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:ring-0"
            >
              <option value="all">All Labs</option>
              {labs.map(l => (
                <option key={l.id} value={l.id}>{l.code} - {l.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Laboratory</th>
                <th className="py-3 px-4">Occupancy State</th>
                <th className="py-3 px-4">Count / Capacity</th>
                <th className="py-3 px-4">Detection Tech</th>
                <th className="py-3 px-4">Utilization</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {filteredLabs.map(lab => {
                const utilPercent = Math.round((lab.currentOccupancy / lab.maxOccupancy) * 100);
                const peopleCounter = sensors.find(s => s.labId === lab.id && s.type === 'ir_people_counter');
                const pir = sensors.find(s => s.labId === lab.id && s.type === 'pir_motion');

                return (
                  <tr key={lab.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">{lab.name}</div>
                      <div className="text-[11px] text-slate-400">{lab.code} • {lab.building}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        lab.occupancyStatus === 'Occupied' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                        lab.occupancyStatus === 'Partially Occupied' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                        'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}>
                        {lab.occupancyStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono-val">
                      <span className="text-base font-bold text-white">{lab.currentOccupancy}</span>
                      <span className="text-slate-400"> / {lab.maxOccupancy} limit</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-300 flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                        {peopleCounter ? 'Dual-beam IR Counter (Accurate)' : 'PIR Micro-Motion Only (Presence)'}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {pir ? `Ceiling PIR: ${pir.value === 1 ? 'Motion Active' : 'No Motion'}` : 'PIR Node Pending'}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-20 bg-slate-800 rounded-full h-2 overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${utilPercent > 80 ? 'bg-rose-500' : utilPercent > 40 ? 'bg-emerald-400' : 'bg-cyan-400'}`}
                            style={{ width: `${Math.min(100, utilPercent)}%` }}
                          />
                        </div>
                        <span className="font-mono-val text-[11px]">{utilPercent}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {currentUser.role === 'admin' || currentUser.role === 'facility_manager' ? (
                        <button
                          onClick={() => handleOpenAdjust(lab.id, lab.currentOccupancy)}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 text-xs font-semibold transition-colors"
                        >
                          Override Count
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-500 italic">View Only</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Occupancy Override Modal */}
      {adjustLabId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <h3 className="text-base font-bold text-white mb-1">Manual Occupancy Adjustment</h3>
            <p className="text-xs text-slate-400 mb-4">
              Authorized supervisor override for safety drills or optical sensor recalibration.
            </p>

            <div className="flex items-center justify-center gap-4 my-6">
              <button
                onClick={() => setManualCount(prev => Math.max(0, prev - 1))}
                className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 transition-colors"
              >
                <UserMinus className="w-5 h-5" />
              </button>
              <div className="text-center">
                <span className="text-4xl font-extrabold text-white font-mono-val">{manualCount}</span>
                <span className="text-xs text-slate-400 block mt-1">Occupants</span>
              </div>
              <button
                onClick={() => setManualCount(prev => prev + 1)}
                className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 transition-colors"
              >
                <UserPlus className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setAdjustLabId(null)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveAdjust}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-950"
              >
                Apply Override
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
