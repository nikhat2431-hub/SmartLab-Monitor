import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  Settings, 
  DollarSign, 
  Clock, 
  Wifi, 
  Cpu, 
  Code2, 
  Copy, 
  Check, 
  ShieldCheck, 
  Terminal, 
  Save, 
  AlertCircle, 
  Play,
  RotateCcw,
  Send
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { settings, updateSettings, currentUser, switchUserRole, triggerSimulationScenario } = useIoT();

  // Local form state
  const [tariff, setTariff] = useState(settings.electricityTariff);
  const [currency, setCurrency] = useState(settings.currency);
  const [currencySymbol, setCurrencySymbol] = useState(settings.currencySymbol);
  const [vacancyDelay, setVacancyDelay] = useState(settings.vacancyDelayMinutes);
  const [peakThreshold, setPeakThreshold] = useState(settings.peakPowerThresholdWatts);
  const [demoMode, setDemoMode] = useState(settings.demoMode);
  const [mqttBroker, setMqttBroker] = useState(settings.mqttBrokerUrl);
  const [mqttPort, setMqttPort] = useState(settings.mqttPort);
  const [mqttTopic, setMqttTopic] = useState(settings.mqttTopicRoot);
  const [restKey, setRestKey] = useState(settings.restWebhookKey);

  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [testPayloadResult, setTestPayloadResult] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleCurrencyChange = (curr: string) => {
    setCurrency(curr);
    switch (curr) {
      case 'USD': setCurrencySymbol('$'); break;
      case 'EUR': setCurrencySymbol('€'); break;
      case 'GBP': setCurrencySymbol('£'); break;
      case 'JPY': setCurrencySymbol('¥'); break;
      default: setCurrencySymbol('$'); break;
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      electricityTariff: tariff,
      currency,
      currencySymbol,
      vacancyDelayMinutes: vacancyDelay,
      peakPowerThresholdWatts: peakThreshold,
      demoMode,
      mqttBrokerUrl: mqttBroker,
      mqttPort: mqttPort,
      mqttTopicRoot: mqttTopic,
      restWebhookKey: restKey,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const esp32Snippet = `// SmartLab Monitor - ESP32 Firmware Telemetry Publisher
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

const char* ssid = "LAB_SECURE_IOT_NET";
const char* password = "REDACTED_WIFI_PASS";
const char* mqtt_server = "${mqttBroker.replace('mqtt://', '')}";
const int mqtt_port = ${mqttPort};
const char* topic = "${mqttTopic}/telemetry";

WiFiClient espClient;
PubSubClient client(espClient);

void setup() {
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) delay(500);
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop();

  StaticJsonDocument<256> doc;
  doc["sensor_id"] = "sns-esp32-node1";
  doc["lab_id"] = "lab-a102";
  doc["type"] = "smart_energy_meter";
  doc["power_watts"] = analogRead(34) * 1.85; // Calibrated CT probe
  doc["voltage"] = 230.2;
  doc["occupancy_count"] = 4; // From optical barrier counter

  char buffer[256];
  serializeJson(doc, buffer);
  client.publish(topic, buffer);
  delay(3000);
}`;

  const jsonPayloadSnippet = `{
  "timestamp": "2026-10-29T10:15:30Z",
  "lab_id": "lab-a102",
  "zone": "PCR Bench",
  "sensors": [
    { "id": "sns-a102-meter", "type": "smart_energy_meter", "power_w": 4850, "voltage_v": 229.4 },
    { "id": "sns-a102-pcount", "type": "ir_people_counter", "count": 4 },
    { "id": "sns-a102-env", "type": "temp_humidity", "temp_c": 21.4, "rh_percent": 46.2 }
  ],
  "checksum": "sha256_verified"
}`;

  const handleTestPacketDispatch = () => {
    setTestPayloadResult('HTTP 200 OK: Ingested telemetry payload successfully. Processed 3 sensor readings.');
    setTimeout(() => setTestPayloadResult(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              System Settings & IoT Gateway Configuration
            </h2>
            <p className="text-xs text-slate-400">
              Electricity tariffs, alert parameters, hardware mode toggles, and microcontroller integration
            </p>
          </div>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>Settings Saved!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Core Tariffs & Thresholds */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-cyan-400" />
            Electricity Tariff & Cost Configuration
          </h3>
          <p className="text-xs text-slate-400 mb-6">
            Configure the baseline electricity tariff used across all financial projections and waste calculations.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Electricity Tariff Rate (per kWh)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono-val text-sm">
                  {currencySymbol}
                </span>
                <input
                  type="number"
                  step="0.001"
                  min="0.01"
                  required
                  value={tariff}
                  onChange={(e) => setTariff(parseFloat(e.target.value) || 0.185)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-sm text-white font-mono-val focus:outline-none focus:border-cyan-500"
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Default: $0.185/kWh commercial rate</span>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Currency
              </label>
              <select
                value={currency}
                onChange={(e) => handleCurrencyChange(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="USD">USD ($) - US Dollar</option>
                <option value="EUR">EUR (€) - Euro</option>
                <option value="GBP">GBP (£) - British Pound</option>
                <option value="JPY">JPY (¥) - Japanese Yen</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Peak Demand Alarm Threshold (Watts)
              </label>
              <input
                type="number"
                step="500"
                min="5000"
                value={peakThreshold}
                onChange={(e) => setPeakThreshold(parseInt(e.target.value) || 18000)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono-val focus:outline-none focus:border-cyan-500"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">{(peakThreshold / 1000).toFixed(1)} kW threshold</span>
            </div>
          </div>
        </div>

        {/* Operational Policies */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            Occupancy & Vacancy Delay Policies
          </h3>
          <p className="text-xs text-slate-400 mb-6">
            Configure system-wide delay buffers to prevent rapid switching or false vacancy alarms.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                System Vacancy Setback Delay (Minutes)
              </label>
              <input
                type="number"
                min="5"
                max="120"
                value={vacancyDelay}
                onChange={(e) => setVacancyDelay(parseInt(e.target.value) || 15)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono-val focus:outline-none focus:border-cyan-500"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Duration of zero occupancy before declaring room vacant and triggering energy waste alert or relay shutoff.
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">Simulation / Demo Mode Toggle</span>
                <span className="text-xs text-slate-400">
                  {demoMode ? 'Synthetic physics engine active' : 'Live hardware gateway listening'}
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={demoMode}
                  onChange={(e) => setDemoMode(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-600"></div>
              </label>
            </div>
          </div>
        </div>

        {/* MQTT & REST API Integration Architecture */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
            <Wifi className="w-4 h-4 text-cyan-400" />
            IoT Gateway & Microcontroller Integration Architecture
          </h3>
          <p className="text-xs text-slate-400 mb-6">
            Connect physical ESP32, ESP8266, Raspberry Pi gateways, or Modbus energy analyzers directly to SmartLab.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">MQTT Broker Endpoint</label>
              <input
                type="text"
                value={mqttBroker}
                onChange={(e) => setMqttBroker(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono-val focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Broker Port (TLS / WSS)</label>
              <input
                type="number"
                value={mqttPort}
                onChange={(e) => setMqttPort(parseInt(e.target.value) || 8883)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono-val focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Code Snippets Section */}
          <div className="space-y-4">
            {/* JSON Schema */}
            <div className="bg-slate-950 rounded-xl border border-slate-800 p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono-val text-cyan-300 font-semibold flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5" /> Telemetry JSON Payload Contract
                </span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(jsonPayloadSnippet, 'json')}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white"
                >
                  {copiedCode === 'json' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'json' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono-val text-slate-300 overflow-x-auto p-2 bg-slate-900/60 rounded">
                {jsonPayloadSnippet}
              </pre>
            </div>

            {/* ESP32 Arduino C++ Firmware Code */}
            <div className="bg-slate-950 rounded-xl border border-slate-800 p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono-val text-emerald-300 font-semibold flex items-center gap-1.5">
                  <Code2 className="w-3.5 h-3.5" /> ESP32 / ESP8266 Arduino C++ Firmware Snippet
                </span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(esp32Snippet, 'esp32')}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white"
                >
                  {copiedCode === 'esp32' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'esp32' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono-val text-slate-300 overflow-x-auto p-2 bg-slate-900/60 rounded max-h-48">
                {esp32Snippet}
              </pre>
            </div>

            {/* Test Payload Simulator */}
            <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold text-white block">Test Webhook Ingestion</span>
                <span className="text-xs text-slate-400">
                  Simulate dispatching a verified telemetry packet into the live queue.
                </span>
              </div>
              <button
                type="button"
                onClick={handleTestPacketDispatch}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-xl text-xs font-semibold transition-colors flex-shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Dispatch Test Packet</span>
              </button>
            </div>

            {testPayloadResult && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 animate-in fade-in flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{testPayloadResult}</span>
              </div>
            )}
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-end gap-3 pt-4">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs bg-cyan-600 hover:bg-cyan-500 text-white shadow-xl shadow-cyan-950 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save All System Configurations</span>
          </button>
        </div>
      </form>
    </div>
  );
};
