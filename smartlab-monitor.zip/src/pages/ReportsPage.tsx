import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  FileText, 
  Download, 
  Printer, 
  Calendar, 
  Building2, 
  TrendingUp, 
  Zap, 
  Users, 
  DollarSign, 
  AlertTriangle,
  CheckCircle2,
  Table
} from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const { 
    labs, 
    devices, 
    hourlyData, 
    settings, 
    totalDailyKwh, 
    exportDataCSV,
    activeAlertCount 
  } = useIoT();

  const [reportPeriod, setReportPeriod] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [selectedLabId, setSelectedLabId] = useState<string>('all');

  const periodMultiplier = reportPeriod === 'daily' ? 1 : reportPeriod === 'weekly' ? 7 : 30;
  const periodKwh = +(totalDailyKwh * periodMultiplier).toFixed(1);
  const periodCost = +(periodKwh * settings.electricityTariff).toFixed(2);
  const vacantWasteKwh = +(periodKwh * 0.22).toFixed(1); // 22% estimated off-hours waste
  const vacantWasteCost = +(vacantWasteKwh * settings.electricityTariff).toFixed(2);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 print:m-0 print:p-0">
      {/* Top Controls Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Facility Audit Reports & Compliance Export
            </h2>
            <p className="text-xs text-slate-400">
              Aggregated energy consumption, occupancy utilization, and cost balance sheet
            </p>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Period selector */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            {(['daily', 'weekly', 'monthly'] as const).map(p => (
              <button
                key={p}
                onClick={() => setReportPeriod(p)}
                className={`px-3 py-1.5 rounded-lg font-medium capitalize transition-colors ${
                  reportPeriod === p
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          {/* Lab filter */}
          <select
            value={selectedLabId}
            onChange={(e) => setSelectedLabId(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All Facilities</option>
            {labs.map(l => (
              <option key={l.id} value={l.id}>{l.code}</option>
            ))}
          </select>

          {/* Print button */}
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-medium transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-cyan-400" />
            <span>Print View</span>
          </button>

          {/* Export CSV button */}
          <button
            onClick={() => exportDataCSV('all')}
            className="flex items-center gap-1.5 px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold shadow-md shadow-cyan-950 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Printable Report Canvas */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 md:p-8 shadow-2xl text-slate-100 print:bg-white print:text-black print:border-none print:shadow-none">
        {/* Report Header */}
        <div className="border-b border-slate-800 pb-6 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-extrabold text-xl md:text-2xl text-white print:text-black tracking-tight">
                SmartLab Monitor
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30 print:border-black print:text-black">
                EXECUTIVE AUDIT REPORT
              </span>
            </div>
            <p className="text-xs text-slate-400 print:text-gray-600">
              Intelligent Energy. Smarter Spaces. Generated for Facility Management & Sustainability Compliance.
            </p>
          </div>

          <div className="text-left sm:text-right text-xs text-slate-400 print:text-gray-600 font-mono-val">
            <div>Reporting Period: <strong className="text-white print:text-black uppercase">{reportPeriod}</strong></div>
            <div>Tariff Applied: <strong className="text-emerald-400 print:text-black">{settings.currencySymbol}{settings.electricityTariff}/kWh</strong></div>
            <div>Timestamp: {new Date().toLocaleString()}</div>
          </div>
        </div>

        {/* Executive Summary Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-[11px] text-slate-400 print:text-gray-600 block uppercase">
              Total Electricity Draw
            </span>
            <span className="text-2xl font-bold font-mono-val text-cyan-400 print:text-black mt-1 block">
              {periodKwh.toLocaleString()} kWh
            </span>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-[11px] text-slate-400 print:text-gray-600 block uppercase">
              Financial Energy Cost
            </span>
            <span className="text-2xl font-bold font-mono-val text-emerald-400 print:text-black mt-1 block">
              {settings.currencySymbol}{periodCost.toLocaleString()}
            </span>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-[11px] text-slate-400 print:text-gray-600 block uppercase">
              Estimated Vacant Waste
            </span>
            <span className="text-2xl font-bold font-mono-val text-rose-400 print:text-black mt-1 block">
              {settings.currencySymbol}{vacantWasteCost}
            </span>
            <span className="text-[10px] text-slate-500">({vacantWasteKwh} kWh)</span>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-[11px] text-slate-400 print:text-gray-600 block uppercase">
              Peak Coincident Demand
            </span>
            <span className="text-2xl font-bold font-mono-val text-amber-400 print:text-black mt-1 block">
              19.4 kW
            </span>
          </div>
        </div>

        {/* Facility Breakdown Table */}
        <div className="mb-8">
          <h3 className="text-sm font-bold text-white print:text-black mb-3 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-cyan-400" />
            1. Laboratory Breakdown & Utilization Profile
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-800 print:border-gray-300">
              <thead className="bg-slate-950 print:bg-gray-100 text-slate-300 print:text-black font-semibold uppercase text-[10px] border-b border-slate-800 print:border-gray-300">
                <tr>
                  <th className="p-3">Facility Name</th>
                  <th className="p-3">Code</th>
                  <th className="p-3">Location</th>
                  <th className="p-3">Max Occ</th>
                  <th className="p-3">Est. Period kWh</th>
                  <th className="p-3">Period Cost</th>
                  <th className="p-3">Waste Potential</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 print:divide-gray-200">
                {labs.map(lab => {
                  const labKwh = +(lab.dailyKwh * periodMultiplier).toFixed(1);
                  const labCost = +(labKwh * settings.electricityTariff).toFixed(2);
                  const labWasteCost = +(labCost * 0.2).toFixed(2);

                  return (
                    <tr key={lab.id} className="hover:bg-slate-800/20">
                      <td className="p-3 font-medium text-white print:text-black">{lab.name}</td>
                      <td className="p-3 font-mono-val text-cyan-400 print:text-black">{lab.code}</td>
                      <td className="p-3 text-slate-400 print:text-gray-700">{lab.building} ({lab.floor})</td>
                      <td className="p-3 font-mono-val">{lab.maxOccupancy} ppl</td>
                      <td className="p-3 font-mono-val font-bold text-cyan-300 print:text-black">{labKwh} kWh</td>
                      <td className="p-3 font-mono-val text-emerald-400 print:text-black">{settings.currencySymbol}{labCost}</td>
                      <td className="p-3 font-mono-val text-rose-400 print:text-black">{settings.currencySymbol}{labWasteCost}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Device Level Comparison */}
        <div className="mb-8">
          <h3 className="text-sm font-bold text-white print:text-black mb-3 flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            2. High-Consumption Equipment Inventory
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-800 print:border-gray-300">
              <thead className="bg-slate-950 print:bg-gray-100 text-slate-300 print:text-black font-semibold uppercase text-[10px] border-b border-slate-800 print:border-gray-300">
                <tr>
                  <th className="p-3">Equipment</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Zone</th>
                  <th className="p-3">Rated Power</th>
                  <th className="p-3">Est. Period Draw</th>
                  <th className="p-3">Vacancy Setback Rule</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 print:divide-gray-200">
                {devices.slice(0, 7).map(d => (
                  <tr key={d.id} className="hover:bg-slate-800/20">
                    <td className="p-3 font-medium text-white print:text-black">{d.name}</td>
                    <td className="p-3 text-slate-400 print:text-gray-700 uppercase text-[10px]">{d.category}</td>
                    <td className="p-3 text-slate-400 print:text-gray-700">{d.zone}</td>
                    <td className="p-3 font-mono-val">{d.nominalWatts} W</td>
                    <td className="p-3 font-mono-val font-bold text-cyan-300 print:text-black">
                      {(d.dailyKwh * periodMultiplier).toFixed(1)} kWh
                    </td>
                    <td className="p-3 font-mono-val">
                      {d.autoShutoffVacant ? (
                        <span className="text-emerald-400 print:text-black font-semibold">Enabled ({d.vacancyShutoffDelayMinutes}m)</span>
                      ) : (
                        <span className="text-slate-500">Critical Always-ON</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Audit Sign-off Block */}
        <div className="pt-6 border-t border-slate-800 print:border-gray-400 flex flex-col sm:flex-row justify-between text-xs text-slate-400 print:text-gray-700">
          <div>
            <p className="font-semibold text-slate-200 print:text-black">Audit Verification Sign-off:</p>
            <p className="font-mono-val text-[11px] mt-1">Certified Lead: Dr. Elena Vance (Lab Operations)</p>
          </div>
          <div className="mt-4 sm:mt-0 text-left sm:text-right font-mono-val text-[11px]">
            <p>Verification Checksum: 0x8F94...B19A</p>
            <p>SmartLab Telemetry Engine v2.4</p>
          </div>
        </div>
      </div>
    </div>
  );
};
