import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  Radio, 
  Users, 
  Zap, 
  Thermometer, 
  Wind, 
  Power, 
  Maximize2, 
  Layers, 
  Info, 
  CheckCircle2, 
  X, 
  Activity,
  Sliders,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { Sensor, Device, Lab } from '../types';

export const LiveMonitoringPage: React.FC = () => {
  const { 
    labs, 
    sensors, 
    devices, 
    totalCurrentWatts, 
    totalOccupancy, 
    lastTickTime,
    settings,
    toggleDeviceState 
  } = useIoT();

  const [selectedLabId, setSelectedLabId] = useState<string>('lab-a102');
  const [selectedZone, setSelectedZone] = useState<string | null>(null);
  const [inspectItem, setInspectItem] = useState<{ type: 'sensor' | 'device'; data: Sensor | Device } | null>(null);
  const [filterType, setFilterType] = useState<string>('all');

  const currentLab = labs.find(l => l.id === selectedLabId) || labs[0];
  const labSensors = sensors.filter(s => s.labId === currentLab?.id);
  const labDevices = devices.filter(d => d.labId === currentLab?.id);

  // Floor plan zone layouts for current lab
  const zoneCoords: Record<string, { top: string; left: string; width: string; height: string; label: string }> = {
    'PCR Bench': { top: '15%', left: '10%', width: '38%', height: '36%', label: 'Zone 1: PCR Amplification & Prep' },
    'Centrifuge Bay': { top: '15%', left: '52%', width: '38%', height: '36%', label: 'Zone 2: Refrigerated Centrifugation' },
    'Fume Hood Area': { top: '56%', left: '10%', width: '38%', height: '36%', label: 'Zone 3: Chemical Exhaust & Fume Hoods' },
    'Cold Storage': { top: '56%', left: '52%', width: '38%', height: '36%', label: 'Zone 4: -80°C Cryo Storage' },
    // Defaults for other labs
    'Electron Microscopy': { top: '15%', left: '10%', width: '40%', height: '38%', label: 'SEM Chamber Bay' },
    'Spin Coater': { top: '15%', left: '54%', width: '36%', height: '38%', label: 'Spin Coating Station' },
    'Chemical Fume Station': { top: '58%', left: '10%', width: '40%', height: '34%', label: 'Solvent Exhaust' },
    'Cleanroom Airlock': { top: '58%', left: '54%', width: '36%', height: '34%', label: 'Airlock Buffer' },
  };

  const getLabOccupancyBadge = (lab: Lab) => {
    if (lab.occupancyStatus === 'Occupied') {
      return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
    } else if (lab.occupancyStatus === 'Partially Occupied') {
      return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
    }
    return 'bg-slate-800 text-slate-400 border-slate-700';
  };

  return (
    <div className="space-y-6">
      {/* Top Controls & Lab Selector */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Spatial Floor Plan & Live Node Matrix
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono-val border border-emerald-500/30">
                STREAMING
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Interactive 2D spatial visualization with physical sensor node placement
            </p>
          </div>
        </div>

        {/* Lab Switcher Tabs */}
        <div className="flex items-center flex-wrap gap-2">
          {labs.map(lab => (
            <button
              key={lab.id}
              onClick={() => {
                setSelectedLabId(lab.id);
                setSelectedZone(null);
                setInspectItem(null);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border flex items-center gap-2 ${
                selectedLabId === lab.id
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-md shadow-cyan-950'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${
                lab.occupancyStatus === 'Occupied' ? 'bg-emerald-400 animate-ping' :
                lab.occupancyStatus === 'Partially Occupied' ? 'bg-amber-400' : 'bg-slate-600'
              }`} />
              <span>{lab.code}</span>
              <span className="text-[10px] opacity-70">({lab.currentOccupancy} ppl)</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Floor Plan & Inspection Drawer Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 2D Interactive Floor Plan (2 cols) */}
        <div className="lg:col-span-2 bg-[#0a0f1d] border border-slate-800 rounded-2xl p-5 shadow-2xl relative flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white">{currentLab.name}</span>
              <span className="text-xs text-slate-400">({currentLab.building}, {currentLab.floor})</span>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className={`px-2 py-0.5 rounded border text-[11px] font-bold ${getLabOccupancyBadge(currentLab)}`}>
                {currentLab.occupancyStatus} ({currentLab.currentOccupancy} / {currentLab.maxOccupancy} limit)
              </span>
              <span className="text-slate-400 font-mono-val">
                {(currentLab.totalPowerWatts / 1000).toFixed(2)} kW
              </span>
            </div>
          </div>

          {/* Floor Plan Canvas */}
          <div className="relative w-full h-[440px] bg-slate-950/90 rounded-xl border border-slate-800/80 p-4 overflow-hidden bg-tech-grid">
            {/* Outer Perimeter Wall with Doorway */}
            <div className="absolute inset-4 border-2 border-slate-700/80 rounded-xl pointer-events-none">
              {/* Doorway Entrance */}
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-28 h-2 bg-cyan-500/80 flex items-center justify-center">
                <span className="text-[9px] font-mono-val text-slate-900 font-extrabold uppercase tracking-widest bg-cyan-400 px-1.5 rounded -translate-y-2">
                  ENTRANCE AIRLOCK
                </span>
              </div>
            </div>

            {/* Entrance Door People Counter Node */}
            <div 
              onClick={() => {
                const pcount = labSensors.find(s => s.type === 'ir_people_counter');
                if (pcount) setInspectItem({ type: 'sensor', data: pcount });
              }}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 cursor-pointer flex items-center gap-1.5 bg-slate-900 border border-cyan-500/60 text-cyan-300 px-2 py-1 rounded-full text-[10px] shadow-lg hover:scale-105 transition-transform"
            >
              <Users className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-mono-val font-bold">{currentLab.currentOccupancy} Counted</span>
            </div>

            {/* Zone Compartments */}
            {currentLab.zones.map((zoneName, idx) => {
              const coords = zoneCoords[zoneName] || {
                top: `${(idx % 2) * 44 + 12}%`,
                left: `${Math.floor(idx / 2) * 45 + 10}%`,
                width: '40%',
                height: '38%',
                label: zoneName,
              };

              const zoneSensors = labSensors.filter(s => s.zone.toLowerCase().includes(zoneName.toLowerCase()) || zoneName.toLowerCase().includes(s.zone.toLowerCase()));
              const zoneDevs = labDevices.filter(d => d.zone.toLowerCase().includes(zoneName.toLowerCase()) || zoneName.toLowerCase().includes(d.zone.toLowerCase()));
              const isZoneSelected = selectedZone === zoneName;

              return (
                <div
                  key={zoneName}
                  onClick={() => setSelectedZone(isZoneSelected ? null : zoneName)}
                  style={{
                    top: coords.top,
                    left: coords.left,
                    width: coords.width,
                    height: coords.height,
                  }}
                  className={`absolute rounded-xl border p-3 cursor-pointer transition-all ${
                    isZoneSelected
                      ? 'bg-cyan-950/40 border-cyan-400 shadow-xl shadow-cyan-950/50'
                      : currentLab.occupancyStatus === 'Occupied'
                      ? 'bg-slate-900/40 border-slate-700/80 hover:border-slate-600'
                      : 'bg-slate-950/50 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold text-slate-200 truncate">{coords.label || zoneName}</span>
                    <span className="text-[9px] font-mono-val text-slate-400">ZONE {idx + 1}</span>
                  </div>

                  {/* Interactive node tags in this zone */}
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {zoneSensors.map(sensor => (
                      <button
                        key={sensor.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          setInspectItem({ type: 'sensor', data: sensor });
                        }}
                        className="flex items-center gap-1 bg-slate-900/90 border border-slate-700 hover:border-cyan-400 text-slate-300 px-1.5 py-0.5 rounded text-[10px] font-mono-val transition-all hover:scale-105"
                        title={sensor.name}
                      >
                        {sensor.type === 'pir_motion' ? <Activity className="w-3 h-3 text-amber-400" /> :
                         sensor.type === 'temp_humidity' ? <Thermometer className="w-3 h-3 text-sky-400" /> :
                         sensor.type === 'smart_energy_meter' ? <Zap className="w-3 h-3 text-cyan-400" /> :
                         <Wind className="w-3 h-3 text-emerald-400" />}
                        <span>{sensor.value} {sensor.unit}</span>
                      </button>
                    ))}

                    {zoneDevs.map(device => (
                      <button
                        key={device.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          setInspectItem({ type: 'device', data: device });
                        }}
                        className={`flex items-center gap-1 border px-1.5 py-0.5 rounded text-[10px] font-mono-val transition-all hover:scale-105 ${
                          device.state === 'ON'
                            ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300'
                            : 'bg-slate-900/80 border-slate-700 text-slate-400'
                        }`}
                        title={`${device.name}: ${device.state}`}
                      >
                        <Power className={`w-3 h-3 ${device.state === 'ON' ? 'text-emerald-400' : 'text-slate-500'}`} />
                        <span className="truncate max-w-[80px]">{device.name.split(' ')[0]}</span>
                        <span>{device.powerWatts}W</span>
                      </button>
                    ))}
                  </div>

                  {/* Motion indicator dot */}
                  {currentLab.occupancyStatus !== 'Vacant' && (
                    <div className="absolute bottom-2 right-2 flex items-center gap-1 text-[9px] text-emerald-400 font-mono-val">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                      <span>PIR ACTIVE</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Floor Plan Legend */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 pt-4 mt-auto border-t border-slate-800">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Occupied Zone
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span> Partial / Motion Detected
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-600"></span> Vacant
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              Click any zone or sensor chip to inspect live telemetry
            </div>
          </div>
        </div>

        {/* Right Inspection & Telemetry Inspector Drawer */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              {inspectItem ? 'Node Inspector' : 'Laboratory Telemetry Stream'}
            </h3>
            {inspectItem && (
              <button
                onClick={() => setInspectItem(null)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {inspectItem ? (
            // Inspected Item Detail View
            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono-val px-2 py-0.5 rounded bg-slate-800 text-slate-300 uppercase">
                    {inspectItem.type}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    (inspectItem.type === 'sensor' ? (inspectItem.data as Sensor).isOnline : (inspectItem.data as Device).connectivity === 'online')
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}>
                    {(inspectItem.type === 'sensor' ? (inspectItem.data as Sensor).isOnline : (inspectItem.data as Device).connectivity === 'online') ? 'ONLINE' : 'OFFLINE'}
                  </span>
                </div>
                <h4 className="text-base font-bold text-white mb-1">{inspectItem.data.name}</h4>
                <p className="text-xs text-slate-400">ID: <code className="text-cyan-400">{inspectItem.data.id}</code></p>
                <p className="text-xs text-slate-400">Zone: <span className="text-slate-200">{inspectItem.data.zone}</span></p>
              </div>

              {inspectItem.type === 'sensor' ? (
                // Sensor Inspector
                (() => {
                  const s = inspectItem.data as Sensor;
                  return (
                    <div className="space-y-3">
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <span className="text-xs text-slate-400 block mb-1">Current Telemetry Value</span>
                        <div className="flex items-baseline gap-2">
                          <span className="text-3xl font-extrabold text-cyan-400 font-mono-val">{s.value}</span>
                          <span className="text-sm font-semibold text-slate-300">{s.unit}</span>
                        </div>
                        {s.secondaryValue && (
                          <div className="mt-2 text-xs text-slate-400 font-mono-val">
                            Secondary: {s.secondaryValue} {s.secondaryUnit}
                          </div>
                        )}
                      </div>

                      {s.history && s.history.length > 0 && (
                        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                          <span className="text-[11px] text-slate-400 block mb-2 font-medium">Recent Waveform Readings</span>
                          <div className="flex items-end gap-1 h-14 pt-2">
                            {s.history.map((h, i) => (
                              <div
                                key={i}
                                className="flex-1 bg-cyan-500/30 hover:bg-cyan-400 rounded-t transition-colors relative group"
                                style={{ height: `${Math.max(15, Math.min(100, (h.value / (s.value || 1)) * 60))}%` }}
                              >
                                <span className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 hidden group-hover:block bg-slate-800 text-[9px] text-white px-1 py-0.5 rounded z-10 whitespace-nowrap">
                                  {h.value} @ {h.time}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()
              ) : (
                // Device Inspector
                (() => {
                  const d = inspectItem.data as Device;
                  return (
                    <div className="space-y-3">
                      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                        <span className="text-xs text-slate-400 block mb-1">Power Consumption</span>
                        <div className="flex items-baseline gap-2">
                          <span className="text-3xl font-extrabold text-cyan-400 font-mono-val">{d.powerWatts}</span>
                          <span className="text-sm font-semibold text-slate-300">Watts</span>
                          <span className="text-xs text-slate-500">({d.nominalWatts}W rated)</span>
                        </div>
                        <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
                          <span>Today's draw:</span>
                          <span className="text-slate-200 font-mono-val font-semibold">{d.dailyKwh} kWh</span>
                        </div>
                      </div>

                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-slate-400">State:</span>
                          <span className={`font-bold ${d.state === 'ON' ? 'text-emerald-400' : 'text-slate-500'}`}>
                            {d.state}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Vacancy Auto-Shutoff:</span>
                          <span className={d.autoShutoffVacant ? 'text-cyan-400 font-semibold' : 'text-slate-500'}>
                            {d.autoShutoffVacant ? `Enabled (${d.vacancyShutoffDelayMinutes}m)` : 'Disabled'}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={async () => {
                          const target = d.state === 'ON' ? 'OFF' : 'ON';
                          await toggleDeviceState(d.id, target);
                          setInspectItem(prev => prev ? { ...prev, data: { ...d, state: target, powerWatts: target === 'OFF' ? 0 : d.nominalWatts } } : null);
                        }}
                        className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                          d.state === 'ON'
                            ? 'bg-rose-600/90 hover:bg-rose-500 text-white shadow-rose-950'
                            : 'bg-emerald-600/90 hover:bg-emerald-500 text-white shadow-emerald-950'
                        }`}
                      >
                        <Power className="w-4 h-4" />
                        <span>Switch Equipment {d.state === 'ON' ? 'OFF' : 'ON'}</span>
                      </button>
                    </div>
                  );
                })()
              )}
            </div>
          ) : (
            // Default Overview of Lab Nodes
            <div className="space-y-4 flex-1 flex flex-col">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">Lab Power Draw</span>
                  <span className="text-xl font-bold text-cyan-400 font-mono-val">
                    {(currentLab.totalPowerWatts / 1000).toFixed(2)} kW
                  </span>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block text-[11px]">Occupancy State</span>
                  <span className="text-xl font-bold text-emerald-400 font-mono-val">
                    {currentLab.currentOccupancy} ppl
                  </span>
                </div>
              </div>

              <div className="flex-1">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
                  Active Sensors in {currentLab.code}
                </span>
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {labSensors.map(sensor => (
                    <div
                      key={sensor.id}
                      onClick={() => setInspectItem({ type: 'sensor', data: sensor })}
                      className="p-2.5 bg-slate-950/70 border border-slate-800/80 hover:border-cyan-500/40 rounded-xl cursor-pointer transition-all flex items-center justify-between text-xs"
                    >
                      <div className="min-w-0 pr-2">
                        <p className="font-semibold text-slate-200 truncate">{sensor.name}</p>
                        <p className="text-[11px] text-slate-400">{sensor.zone}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <span className="font-mono-val font-bold text-cyan-400">{sensor.value} {sensor.unit}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 text-xs text-slate-400 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-cyan-400" />
                <span>Sensors stream over local secure MQTT broker</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
