import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  Bell, 
  AlertTriangle, 
  AlertCircle, 
  Info, 
  CheckCircle2, 
  Clock, 
  Building2, 
  Power, 
  Cpu, 
  Trash2, 
  Filter, 
  Sliders, 
  Volume2, 
  Mail,
  Check
} from 'lucide-react';
import { Alert, AlertSeverity, AlertType } from '../types';

export const AlertsPage: React.FC = () => {
  const { 
    alerts, 
    acknowledgeAlert, 
    resolveAlert, 
    deleteAlert, 
    clearAllAlerts, 
    settings, 
    updateSettings, 
    currentUser 
  } = useIoT();

  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('unresolved');
  const [labFilter, setLabFilter] = useState<string>('all');

  const filteredAlerts = alerts.filter(alert => {
    if (severityFilter !== 'all' && alert.severity !== severityFilter) return false;
    if (labFilter !== 'all' && alert.labId !== labFilter) return false;
    if (statusFilter === 'unresolved' && alert.resolved) return false;
    if (statusFilter === 'resolved' && !alert.resolved) return false;
    if (statusFilter === 'unacknowledged' && alert.acknowledged) return false;
    return true;
  });

  const getSeverityBadge = (severity: AlertSeverity) => {
    switch (severity) {
      case 'critical':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'warning':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'info':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30';
    }
  };

  const getSeverityIcon = (severity: AlertSeverity) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="w-5 h-5 text-rose-400" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-amber-400" />;
      case 'info':
        return <Info className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Filter and Actions Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Incident & Anomaly Detection Center
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono-val">
                {alerts.filter(a => !a.resolved).length} Active Incidents
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Real-time audit log of energy spikes, vacant waste, and telemetry dropouts
            </p>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All States</option>
            <option value="unresolved">Unresolved Only</option>
            <option value="unacknowledged">Unacknowledged Only</option>
            <option value="resolved">Resolved History</option>
          </select>

          {/* Severity Filter */}
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All Severities</option>
            <option value="critical">Critical</option>
            <option value="warning">Warning</option>
            <option value="info">Informational</option>
          </select>

          {alerts.length > 0 && (
            <button
              onClick={clearAllAlerts}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-rose-950/40 text-slate-300 hover:text-rose-300 border border-slate-700 rounded-xl font-medium transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          )}
        </div>
      </div>

      {/* Notification Preferences Strip */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-4 text-slate-300">
          <span className="font-semibold text-slate-400 uppercase tracking-wider text-[10px]">
            Alert Preferences:
          </span>
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.emailAlertsEnabled}
              onChange={(e) => updateSettings({ emailAlertsEnabled: e.target.checked })}
              className="rounded text-cyan-500 focus:ring-0 bg-slate-800 border-slate-700"
            />
            <Mail className="w-3.5 h-3.5 text-cyan-400" />
            <span>Email Facility Leads</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={settings.autoDetectWaste}
              onChange={(e) => updateSettings({ autoDetectWaste: e.target.checked })}
              className="rounded text-cyan-500 focus:ring-0 bg-slate-800 border-slate-700"
            />
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Automated Vacant Waste Detection</span>
          </label>
        </div>
        <div className="text-slate-400 text-[11px]">
          Peak Threshold: <strong className="text-white font-mono-val">{settings.peakPowerThresholdWatts / 1000} kW</strong>
        </div>
      </div>

      {/* Alert Feed */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-3 opacity-80" />
            <h3 className="text-base font-bold text-white mb-1">No Active Incident Alerts</h3>
            <p className="text-xs max-w-sm mx-auto">
              All monitored laboratories, smart relays, and IoT sensors are operating within established safe parameters.
            </p>
          </div>
        ) : (
          filteredAlerts.map(alert => (
            <div
              key={alert.id}
              className={`bg-slate-900/80 border rounded-2xl p-5 shadow-lg transition-all ${
                alert.resolved
                  ? 'border-slate-800 opacity-60'
                  : alert.severity === 'critical'
                  ? 'border-rose-500/50 bg-rose-950/10'
                  : alert.severity === 'warning'
                  ? 'border-amber-500/50 bg-amber-950/10'
                  : 'border-slate-800'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="flex items-start gap-3.5">
                  <div className={`p-2.5 rounded-xl border flex-shrink-0 ${getSeverityBadge(alert.severity)}`}>
                    {getSeverityIcon(alert.severity)}
                  </div>

                  <div>
                    <div className="flex items-center flex-wrap gap-2 mb-1">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${getSeverityBadge(alert.severity)}`}>
                        {alert.severity}
                      </span>
                      <span className="text-xs text-slate-400 font-mono-val">{alert.timestamp}</span>
                      {alert.acknowledged && !alert.resolved && (
                        <span className="text-[10px] font-semibold bg-slate-800 text-cyan-300 px-2 py-0.5 rounded border border-slate-700">
                          ACKNOWLEDGED
                        </span>
                      )}
                      {alert.resolved && (
                        <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30">
                          RESOLVED
                        </span>
                      )}
                    </div>

                    <h4 className="text-sm font-bold text-white mb-1">
                      {alert.description}
                    </h4>

                    <div className="flex items-center flex-wrap gap-3 text-xs text-slate-400 mt-2">
                      <span className="flex items-center gap-1 text-cyan-300">
                        <Building2 className="w-3.5 h-3.5" />
                        {alert.labName}
                      </span>
                      {alert.deviceName && (
                        <span className="flex items-center gap-1 text-slate-300">
                          <Power className="w-3.5 h-3.5 text-slate-500" />
                          {alert.deviceName}
                        </span>
                      )}
                      {alert.sensorName && (
                        <span className="flex items-center gap-1 text-slate-300">
                          <Cpu className="w-3.5 h-3.5 text-slate-500" />
                          {alert.sensorName}
                        </span>
                      )}
                    </div>

                    {/* Recommended action box */}
                    <div className="mt-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-xs">
                      <span className="text-amber-400 font-semibold uppercase text-[10px] block mb-0.5">
                        Recommended Mitigation:
                      </span>
                      <p className="text-slate-300 leading-relaxed">
                        {alert.recommendedAction}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Right Action Buttons */}
                <div className="flex items-center gap-2 self-end md:self-start flex-shrink-0 pt-2 md:pt-0">
                  {!alert.acknowledged && (
                    <button
                      onClick={() => acknowledgeAlert(alert.id)}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors"
                    >
                      Acknowledge
                    </button>
                  )}

                  {!alert.resolved ? (
                    <button
                      onClick={() => resolveAlert(alert.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-950 transition-colors"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Resolve</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => deleteAlert(alert.id)}
                      className="p-1.5 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                      title="Delete record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
