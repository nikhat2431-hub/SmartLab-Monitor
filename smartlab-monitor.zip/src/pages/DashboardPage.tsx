import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  Zap, 
  Users, 
  DollarSign, 
  Activity, 
  Thermometer, 
  Wind, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowUpRight, 
  TrendingDown, 
  TrendingUp, 
  Building2,
  Cpu,
  Clock,
  Sparkles,
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { NavPage } from '../components/layout/Sidebar';

interface DashboardPageProps {
  onNavigate: (page: NavPage) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { 
    labs, 
    totalCurrentWatts, 
    totalDailyKwh, 
    totalOccupancy, 
    overallOccupancyStatus, 
    estimatedDailyCost, 
    energyEfficiencyScore, 
    activeAlertCount,
    unresolvedAlerts,
    avgTemp,
    avgHumidity,
    hourlyData,
    settings,
    totalDevicesOnline,
    totalSensorsOnline,
    devices,
    sensors,
    lastTickTime,
  } = useIoT();

  const [activeChartTab, setActiveChartTab] = useState<'power' | 'occupancy' | 'comparison' | 'per_person'>('power');

  const powerKw = (totalCurrentWatts / 1000).toFixed(2);

  // Status color helpers
  const getOccupancyColor = (status: string) => {
    switch (status) {
      case 'Occupied':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'Partially Occupied':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'Vacant':
        return 'text-slate-400 bg-slate-800/80 border-slate-700';
      default:
        return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20';
    }
  };

  return (
    <div className="space-y-6">
      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Current Power */}
        <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-cyan-500/40 transition-all">
          <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl group-hover:bg-cyan-500/10 transition-colors pointer-events-none" />
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Current Power Demand</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-2xl md:text-3xl font-extrabold text-white font-mono-val">{powerKw}</span>
            <span className="text-sm font-semibold text-cyan-400">kW</span>
            <span className="text-xs text-slate-400">({totalCurrentWatts.toLocaleString()} W)</span>
          </div>
          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <TrendingDown className="w-3.5 h-3.5" /> -4.2% vs peak
            </span>
            <span className="text-slate-400 flex items-center gap-1 font-mono-val">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span> Live
            </span>
          </div>
        </div>

        {/* Card 2: Today's Energy Usage */}
        <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-sky-500/40 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Today's Energy</span>
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-2xl md:text-3xl font-extrabold text-white font-mono-val">{totalDailyKwh}</span>
            <span className="text-sm font-semibold text-sky-400">kWh</span>
          </div>
          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
            <span className="text-slate-400">Cumulative campus draw</span>
            <span className="text-slate-300 font-medium font-mono-val">4 Labs active</span>
          </div>
        </div>

        {/* Card 3: Current Occupancy & Status */}
        <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-emerald-500/40 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Campus Occupancy</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-3 mb-1">
            <span className="text-2xl md:text-3xl font-extrabold text-white font-mono-val">{totalOccupancy}</span>
            <span className="text-xs text-slate-400 font-medium">Persons across zones</span>
          </div>
          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
            <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold border ${getOccupancyColor(overallOccupancyStatus)}`}>
              {overallOccupancyStatus}
            </span>
            <span className="text-slate-400 text-[11px] flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-cyan-400" /> Non-invasive IR
            </span>
          </div>
        </div>

        {/* Card 4: Estimated Energy Cost */}
        <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl p-5 shadow-lg relative overflow-hidden group hover:border-amber-500/40 transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Today's Electricity Cost</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-2xl md:text-3xl font-extrabold text-white font-mono-val">
              {settings.currencySymbol}{estimatedDailyCost}
            </span>
            <span className="text-xs text-slate-400 font-medium">({settings.currency})</span>
          </div>
          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
            <span className="text-slate-400">Tariff Rate:</span>
            <span className="text-amber-400 font-mono-val font-semibold">
              {settings.currencySymbol}{settings.electricityTariff.toFixed(3)}/kWh
            </span>
          </div>
        </div>
      </div>

      {/* Second KPI Strip: Efficiency, Environment, Alerts, Connectivity */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Efficiency Score */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-center gap-4">
          <div className="relative w-14 h-14 flex-shrink-0 flex items-center justify-center">
            <svg className="w-14 h-14 -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-slate-800"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="text-emerald-400 transition-all duration-500"
                strokeDasharray={`${energyEfficiencyScore}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <span className="absolute font-mono-val text-sm font-extrabold text-white">
              {energyEfficiencyScore}
            </span>
          </div>
          <div>
            <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Energy Efficiency</span>
            </div>
            <div className="text-sm font-bold text-slate-100">
              {energyEfficiencyScore > 85 ? 'Optimal Efficiency' : energyEfficiencyScore > 70 ? 'Moderate Waste' : 'High Vacancy Drain'}
            </div>
            <div className="text-[11px] text-slate-400">Score based on occupancy vs base-load</div>
          </div>
        </div>

        {/* Environmental Conditions */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
          <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex-shrink-0">
            <Thermometer className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs text-slate-400 font-medium flex items-center justify-between">
              <span>Environment</span>
              <span className="text-[11px] text-emerald-400">Nominal</span>
            </div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-lg font-bold text-white font-mono-val">{avgTemp}°C</span>
              <span className="text-xs text-slate-400 font-mono-val">| {avgHumidity}% RH</span>
            </div>
            <div className="text-[11px] text-slate-400 truncate">AQI: 45 (ISO 6 cleanroom standard)</div>
          </div>
        </div>

        {/* Active Alerts */}
        <div 
          onClick={() => onNavigate('alerts')}
          className="bg-slate-900/60 border border-slate-800 hover:border-amber-500/40 rounded-xl p-4 flex items-center gap-3 cursor-pointer transition-colors group"
        >
          <div className={`p-3 rounded-xl flex-shrink-0 ${
            activeAlertCount > 0 ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
          }`}>
            {activeAlertCount > 0 ? <AlertTriangle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs text-slate-400 font-medium flex items-center justify-between">
              <span>Active Alerts</span>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition-colors" />
            </div>
            <div className="text-lg font-bold text-white font-mono-val">
              {activeAlertCount} {activeAlertCount === 1 ? 'Incident' : 'Incidents'}
            </div>
            <div className="text-[11px] text-amber-400/90 truncate">
              {activeAlertCount > 0 ? `${unresolvedAlerts[0]?.description.slice(0, 32)}...` : 'Zero unresolved anomalies'}
            </div>
          </div>
        </div>

        {/* Device Connectivity */}
        <div 
          onClick={() => onNavigate('devices')}
          className="bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 rounded-xl p-4 flex items-center gap-3 cursor-pointer transition-colors group"
        >
          <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex-shrink-0">
            <Cpu className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs text-slate-400 font-medium flex items-center justify-between">
              <span>IoT Fleet Mesh</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
            <div className="text-lg font-bold text-white font-mono-val">
              {totalDevicesOnline + totalSensorsOnline} Nodes
            </div>
            <div className="text-[11px] text-slate-400">
              {totalDevicesOnline} Relays • {totalSensorsOnline} Telemetry Probes
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Charts Section */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-cyan-400" />
              Dynamic Telemetry & Energy Usage Patterns
            </h2>
            <p className="text-xs text-slate-400">
              24-hour temporal resolution with base-load tracking and occupancy correlation
            </p>
          </div>

          {/* Chart View Switcher Tabs */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs self-start md:self-auto">
            <button
              onClick={() => setActiveChartTab('power')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeChartTab === 'power'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Power (24h)
            </button>
            <button
              onClick={() => setActiveChartTab('occupancy')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeChartTab === 'occupancy'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Occupancy Levels
            </button>
            <button
              onClick={() => setActiveChartTab('comparison')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeChartTab === 'comparison'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Prior Day Compare
            </button>
            <button
              onClick={() => setActiveChartTab('per_person')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeChartTab === 'per_person'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              kW / Person
            </button>
          </div>
        </div>

        {/* Charts Body */}
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {activeChartTab === 'power' ? (
              <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="powerGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="baseLoadGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#64748b" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#64748b" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} unit=" kW" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} kW`]}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Area type="monotone" dataKey="powerKw" name="Total Power Demand (kW)" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#powerGradient)" />
                <Area type="monotone" dataKey="baseLoadKw" name="Unoccupied Base Load (kW)" stroke="#94a3b8" strokeDasharray="4 4" fillOpacity={1} fill="url(#baseLoadGradient)" />
              </AreaChart>
            ) : activeChartTab === 'occupancy' ? (
              <BarChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} unit=" ppl" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} persons`, 'Occupancy Count']}
                />
                <Bar dataKey="occupancy" name="Laboratory Occupancy" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            ) : activeChartTab === 'comparison' ? (
              <LineChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} unit=" kW" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} kW`]}
                />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Line type="monotone" dataKey="powerKw" name="Today Power Demand (kW)" stroke="#06b6d4" strokeWidth={2.5} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="previousDayKw" name="Yesterday Benchmark (kW)" stroke="#f59e0b" strokeDasharray="5 5" strokeWidth={2} dot={{ r: 2 }} />
              </LineChart>
            ) : (
              <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="perPersonGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} unit=" kW/p" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} kW/person`]}
                />
                <Area type="monotone" dataKey="energyPerPersonKwh" name="Power Intensity per Occupant (kW/person)" stroke="#a855f7" strokeWidth={2} fill="url(#perPersonGradient)" />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Laboratory Status Panel */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-cyan-400" />
              Laboratory Operating Status Matrix
            </h3>
            <p className="text-xs text-slate-400">
              Live status, power allocation, and occupancy across laboratory suites
            </p>
          </div>
          <button
            onClick={() => onNavigate('labs')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
          >
            Manage Labs <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {labs.map(lab => {
            const labSensors = sensors.filter(s => s.labId === lab.id);
            const labDevices = devices.filter(d => d.labId === lab.id);
            const onlineDevs = labDevices.filter(d => d.connectivity === 'online').length;
            const kw = (lab.totalPowerWatts / 1000).toFixed(2);
            const isAlert = lab.alertCount > 0;

            return (
              <div
                key={lab.id}
                className={`bg-slate-950/60 border rounded-xl p-4 transition-all hover:bg-slate-950 ${
                  isAlert ? 'border-amber-500/40' : 'border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <span className="text-[11px] font-mono-val px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {lab.code}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getOccupancyColor(lab.occupancyStatus)}`}>
                    {lab.occupancyStatus}
                  </span>
                </div>

                <h4 className="text-sm font-bold text-white truncate mb-1" title={lab.name}>
                  {lab.name}
                </h4>
                <div className="text-[11px] text-slate-400 mb-3 truncate">
                  {lab.building} • {lab.floor}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/60 mb-3">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Power</span>
                    <span className="font-mono-val font-bold text-cyan-400">{kw} kW</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Occupancy</span>
                    <span className="font-mono-val font-bold text-emerald-400">
                      {lab.currentOccupancy} / {lab.maxOccupancy}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                  <span className="flex items-center gap-1 font-mono-val text-[10px]">
                    <Clock className="w-3 h-3 text-slate-500" />
                    {lab.operatingHours.start} - {lab.operatingHours.end}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {onlineDevs}/{labDevices.length} Devs Online
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
