import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  Building2, 
  Plus, 
  Edit3, 
  Trash2, 
  Users, 
  Zap, 
  Clock, 
  Layers, 
  CheckCircle2, 
  AlertTriangle, 
  X,
  TrendingUp,
  Cpu,
  Power
} from 'lucide-react';
import { Lab } from '../types';

export const LabsPage: React.FC = () => {
  const { labs, sensors, devices, addLab, updateLab, deleteLab, currentUser } = useIoT();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingLab, setEditingLab] = useState<Lab | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [building, setBuilding] = useState('');
  const [floor, setFloor] = useState('Floor 1');
  const [maxOccupancy, setMaxOccupancy] = useState(10);
  const [startTime, setStartTime] = useState('08:00');
  const [endTime, setEndTime] = useState('18:00');
  const [zonesStr, setZonesStr] = useState('Main Bench, Prep Area, Analysis Bay');

  const handleOpenAdd = () => {
    setName('');
    setCode(`LAB-${Math.floor(100 + Math.random() * 900)}`);
    setBuilding('Science Center');
    setFloor('Floor 2');
    setMaxOccupancy(12);
    setStartTime('08:00');
    setEndTime('18:30');
    setZonesStr('Main Workcell, Reagent Station, Storage');
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (lab: Lab) => {
    setEditingLab(lab);
    setName(lab.name);
    setCode(lab.code);
    setBuilding(lab.building);
    setFloor(lab.floor);
    setMaxOccupancy(lab.maxOccupancy);
    setStartTime(lab.operatingHours.start);
    setEndTime(lab.operatingHours.end);
    setZonesStr(lab.zones.join(', '));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const zonesArray = zonesStr.split(',').map(z => z.trim()).filter(Boolean);

    if (editingLab) {
      updateLab({
        ...editingLab,
        name,
        code,
        building,
        floor,
        maxOccupancy,
        operatingHours: { start: startTime, end: endTime },
        zones: zonesArray,
      });
      setEditingLab(null);
    } else {
      addLab({
        name,
        code,
        building,
        floor,
        maxOccupancy,
        currentOccupancy: 0,
        occupancyStatus: 'Vacant',
        targetTemp: 21.0,
        targetHumidity: 45.0,
        operatingHours: { start: startTime, end: endTime },
        zones: zonesArray,
      });
      setIsAddModalOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Laboratory Directory & Zone Architecture
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono-val">
                {labs.length} Facilities
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Facility boundaries, operating schedules, zone allocations, and sensor density
            </p>
          </div>
        </div>

        {currentUser.role === 'admin' && (
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-cyan-950 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Register New Laboratory</span>
          </button>
        )}
      </div>

      {/* Comparative Performance Matrix */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-cyan-400" />
          Cross-Facility Comparative Efficiency Matrix
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Benchmarking real-time power draw, occupant intensity, and sensor distribution across spaces
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Facility / Code</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4">Power Load</th>
                <th className="py-3 px-4">Occupancy</th>
                <th className="py-3 px-4">Intensity (W / Occupant)</th>
                <th className="py-3 px-4">Mesh Nodes</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {labs.map(lab => {
                const labSensors = sensors.filter(s => s.labId === lab.id);
                const labDevs = devices.filter(d => d.labId === lab.id);
                const wPerPerson = lab.currentOccupancy > 0 
                  ? Math.round(lab.totalPowerWatts / lab.currentOccupancy) 
                  : 0;

                return (
                  <tr key={lab.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white">{lab.name}</div>
                      <div className="text-[11px] font-mono-val text-cyan-400">{lab.code}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      {lab.building} • {lab.floor}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono-val font-bold text-cyan-400 text-sm">
                        {(lab.totalPowerWatts / 1000).toFixed(2)} kW
                      </span>
                      <span className="text-[10px] text-slate-500 block">Today: {lab.dailyKwh} kWh</span>
                    </td>
                    <td className="py-3 px-4 font-mono-val">
                      <span className="font-bold text-emerald-400">{lab.currentOccupancy}</span>
                      <span className="text-slate-400"> / {lab.maxOccupancy} limit</span>
                    </td>
                    <td className="py-3 px-4 font-mono-val">
                      {wPerPerson > 0 ? (
                        <span className="text-purple-400 font-semibold">{wPerPerson} W/p</span>
                      ) : (
                        <span className="text-slate-500 italic">Vacant (Standby)</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      <span className="font-mono-val text-white">{labSensors.length}</span> Sensors • <span className="font-mono-val text-white">{labDevs.length}</span> Relays
                    </td>
                    <td className="py-3 px-4 text-right">
                      {currentUser.role === 'admin' ? (
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenEdit(lab)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 transition-colors"
                            title="Edit Lab"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          {labs.length > 1 && (
                            <button
                              onClick={() => deleteLab(lab.id)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/40 text-rose-400 transition-colors"
                              title="Delete Lab"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-500">View Only</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Lab Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {labs.map(lab => {
          const labSensors = sensors.filter(s => s.labId === lab.id);
          const labDevs = devices.filter(d => d.labId === lab.id);

          return (
            <div key={lab.id} className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono-val px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-bold">
                      {lab.code}
                    </span>
                    <span className="text-xs text-slate-400">{lab.building} ({lab.floor})</span>
                  </div>
                  <h3 className="text-lg font-bold text-white">{lab.name}</h3>
                </div>

                <div className="text-right">
                  <span className="text-xl font-mono-val font-extrabold text-cyan-400 block">
                    {(lab.totalPowerWatts / 1000).toFixed(2)} kW
                  </span>
                  <span className="text-[11px] text-slate-400">Active Load</span>
                </div>
              </div>

              {/* Operating hours & zones */}
              <div className="grid grid-cols-2 gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800/80 mb-4 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">Operating Schedule</span>
                  <span className="font-mono-val text-slate-200 font-medium">
                    {lab.operatingHours.start} - {lab.operatingHours.end}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Headcount Capacity</span>
                  <span className="font-mono-val text-emerald-400 font-medium">
                    {lab.currentOccupancy} Present (Cap: {lab.maxOccupancy})
                  </span>
                </div>
              </div>

              {/* Zones Pill List */}
              <div className="mb-4">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
                  Configured Functional Zones ({lab.zones.length}):
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {lab.zones.map(z => (
                    <span key={z} className="px-2.5 py-1 rounded-lg bg-slate-800/70 border border-slate-700 text-slate-300 text-xs">
                      {z}
                    </span>
                  ))}
                </div>
              </div>

              {/* Hardware Mesh Count */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                    {labSensors.length} Sensors
                  </span>
                  <span className="flex items-center gap-1">
                    <Power className="w-3.5 h-3.5 text-emerald-400" />
                    {labDevs.length} Relays
                  </span>
                </div>

                {currentUser.role === 'admin' && (
                  <button
                    onClick={() => handleOpenEdit(lab)}
                    className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold"
                  >
                    Configure Zones & Hours →
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Lab Modal */}
      {(isAddModalOpen || editingLab) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Building2 className="w-5 h-5 text-cyan-400" />
                {editingLab ? 'Edit Laboratory Record' : 'Register New Laboratory'}
              </h3>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingLab(null);
                }}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-300 block mb-1">Laboratory Code</label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="e.g. LAB-E101"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-300 block mb-1">Max Occupancy Limit</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="50"
                    value={maxOccupancy}
                    onChange={(e) => setMaxOccupancy(parseInt(e.target.value) || 10)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">Laboratory Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Synthetic Biology Core"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-300 block mb-1">Building</label>
                  <input
                    type="text"
                    required
                    value={building}
                    onChange={(e) => setBuilding(e.target.value)}
                    placeholder="e.g. Science Complex A"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-300 block mb-1">Floor</label>
                  <input
                    type="text"
                    required
                    value={floor}
                    onChange={(e) => setFloor(e.target.value)}
                    placeholder="e.g. Floor 2"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-slate-300 block mb-1">Operating Hours Start</label>
                  <input
                    type="time"
                    required
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-300 block mb-1">Operating Hours End</label>
                  <input
                    type="time"
                    required
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">Functional Zones (Comma separated)</label>
                <input
                  type="text"
                  required
                  value={zonesStr}
                  onChange={(e) => setZonesStr(e.target.value)}
                  placeholder="e.g. Cell Prep, Centrifugation, Cold Storage"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingLab(null);
                  }}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-950"
                >
                  Save Laboratory
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
