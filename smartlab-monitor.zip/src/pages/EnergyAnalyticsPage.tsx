import React, { useState, useMemo } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  TrendingUp, 
  DollarSign, 
  Zap, 
  BarChart3, 
  Calendar, 
  Filter, 
  Sparkles, 
  Lightbulb, 
  Check, 
  ArrowUpRight, 
  ShieldAlert, 
  SlidersHorizontal,
  Download
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { SAVINGS_RECOMMENDATIONS } from '../data/initialData';

export const EnergyAnalyticsPage: React.FC = () => {
  const { 
    labs, 
    devices, 
    hourlyData, 
    settings, 
    updateSettings, 
    totalDailyKwh,
    exportDataCSV 
  } = useIoT();

  const [dateFilter, setDateFilter] = useState<'today' | '7days' | '30days'>('today');
  const [selectedLabId, setSelectedLabId] = useState<string>('all');
  const [tariffInput, setTariffInput] = useState<number>(settings.electricityTariff);
  const [appliedRecs, setAppliedRecs] = useState<Record<string, boolean>>({});

  // Filtered devices
  const filteredDevices = useMemo(() => {
    if (selectedLabId === 'all') return devices;
    return devices.filter(d => d.labId === selectedLabId);
  }, [devices, selectedLabId]);

  // Breakdown by Category for Pie Chart
  const categoryBreakdown = useMemo(() => {
    const map: Record<string, number> = {};
    filteredDevices.forEach(d => {
      const cat = d.category.replace('_', ' ').toUpperCase();
      map[cat] = (map[cat] || 0) + d.dailyKwh;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value: +value.toFixed(1) }));
  }, [filteredDevices]);

  const COLORS = ['#06b6d4', '#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  // Multiplier for date range
  const dateMultiplier = dateFilter === 'today' ? 1 : dateFilter === '7days' ? 6.8 : 28.5;
  const currentTotalKwh = +(totalDailyKwh * dateMultiplier).toFixed(1);
  const currentTotalCost = +(currentTotalKwh * tariffInput).toFixed(2);
  const peakDemandKw = 19.4; // peak hourly recorded
  const baseLoadKwh = +(currentTotalKwh * 0.38).toFixed(1);
  const occupiedKwh = +(currentTotalKwh * 0.62).toFixed(1);

  const handleTariffChange = (val: number) => {
    setTariffInput(val);
    updateSettings({ electricityTariff: val });
  };

  const toggleApplyRec = (recId: string) => {
    setAppliedRecs(prev => ({ ...prev, [recId]: !prev[recId] }));
  };

  return (
    <div className="space-y-6">
      {/* Top Filter Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Advanced Energy Telemetry & Cost Accounting
            </h2>
            <p className="text-xs text-slate-400">
              Correlated consumption analytics, base-load analysis, and tariff projections
            </p>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Date Filter */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            {(['today', '7days', '30days'] as const).map(df => (
              <button
                key={df}
                onClick={() => setDateFilter(df)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  dateFilter === df
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {df === 'today' ? 'Today' : df === '7days' ? 'Last 7 Days' : 'Last 30 Days'}
              </button>
            ))}
          </div>

          {/* Lab Filter */}
          <select
            value={selectedLabId}
            onChange={(e) => setSelectedLabId(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-2 font-medium"
          >
            <option value="all">All Laboratory Suites</option>
            {labs.map(l => (
              <option key={l.id} value={l.id}>{l.code} - {l.name}</option>
            ))}
          </select>

          <button
            onClick={() => exportDataCSV('energy')}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-medium transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Analytics KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
            Total Consumption ({dateFilter})
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-mono-val">{currentTotalKwh}</span>
            <span className="text-sm font-semibold text-cyan-400">kWh</span>
          </div>
          <div className="text-xs text-slate-400 mt-2 flex items-center justify-between">
            <span>Occupied: <strong className="text-emerald-400 font-mono-val">{occupiedKwh} kWh</strong></span>
            <span>Base-load: <strong className="text-rose-400 font-mono-val">{baseLoadKwh} kWh</strong></span>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
            Peak Demand Load
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-amber-400 font-mono-val">{peakDemandKw}</span>
            <span className="text-sm font-semibold text-slate-300">kW</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Campus Cap: <span className="text-slate-300 font-mono-val">{(settings.peakPowerThresholdWatts / 1000).toFixed(1)} kW</span> (Safe)
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
            Estimated Electricity Cost
          </span>
          <div className="flex items-baseline gap-1">
            <span className="text-3xl font-extrabold text-emerald-400 font-mono-val">
              {settings.currencySymbol}{currentTotalCost}
            </span>
            <span className="text-xs text-slate-400">({settings.currency})</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Cost = kWh × {settings.currencySymbol}{tariffInput.toFixed(3)}
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
            Unoccupied Base Load
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-200 font-mono-val">38.2%</span>
            <span className="text-xs text-rose-400 font-semibold">of total draw</span>
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Potential for up to $3,200/yr savings
          </div>
        </div>
      </div>

      {/* Main Analytics Charts: Hourly Occupied vs Unoccupied & Equipment Category Share */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Occupied vs Unoccupied Power (2 cols) */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-cyan-400" />
                Occupied vs Unoccupied Power Profile
              </h3>
              <p className="text-xs text-slate-400">
                Segmented energy draw: active researcher hours (cyan) vs off-hours standby waste (rose)
              </p>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="occGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.5}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="vacGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} unit=" kW" />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Area type="monotone" dataKey="occupiedPowerKw" name="Occupied Hours Demand (kW)" stroke="#06b6d4" strokeWidth={2} fill="url(#occGradient)" />
                <Area type="monotone" dataKey="vacantPowerKw" name="Unoccupied Base Load (kW)" stroke="#f43f5e" strokeWidth={2} fill="url(#vacGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Equipment Category Breakdown (1 col) */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col">
          <div className="mb-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-cyan-400" />
              Category Consumption Share
            </h3>
            <p className="text-xs text-slate-400">
              Daily kWh distribution across equipment classes
            </p>
          </div>

          <div className="h-56 w-full flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryBreakdown}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {categoryBreakdown.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-800">
            {categoryBreakdown.map((cat, idx) => (
              <div key={cat.name} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                <span className="truncate text-slate-300 text-[11px]">{cat.name}: <strong className="text-white font-mono-val">{cat.value} kWh</strong></span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Electricity Tariff Simulator */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <SlidersHorizontal className="w-5 h-5 text-cyan-400" />
              Electricity Tariff Simulator & Formula
            </h3>
            <p className="text-xs text-slate-400">
              Formula: <code className="bg-slate-950 px-2 py-0.5 rounded text-cyan-300 font-mono-val font-semibold">Energy Cost = kWh × Tariff ({settings.currencySymbol}/kWh)</code>
            </p>
          </div>

          <div className="flex items-center gap-4 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
            <span className="text-xs text-slate-400">Current Tariff:</span>
            <span className="text-lg font-bold text-emerald-400 font-mono-val">
              {settings.currencySymbol}{tariffInput.toFixed(3)} / kWh
            </span>
          </div>
        </div>

        <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800/80 flex flex-col md:flex-row items-center gap-6">
          <div className="flex-1 w-full space-y-2">
            <div className="flex justify-between text-xs text-slate-300">
              <span>Simulate Utility Rate Adjustment</span>
              <span className="font-mono-val text-cyan-400">{settings.currencySymbol}{tariffInput.toFixed(3)}</span>
            </div>
            <input
              type="range"
              min={0.08}
              max={0.45}
              step={0.005}
              value={tariffInput}
              onChange={(e) => handleTariffChange(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono-val">
              <span>{settings.currencySymbol}0.08 (Off-peak Hydro)</span>
              <span>{settings.currencySymbol}0.25 (Standard Commercial)</span>
              <span>{settings.currencySymbol}0.45 (Peak Summer Grid)</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs w-full md:w-auto flex-shrink-0">
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-center">
              <span className="text-slate-400 block text-[10px]">Projected Monthly</span>
              <span className="text-base font-bold text-white font-mono-val">
                {settings.currencySymbol}{(currentTotalCost * 30).toFixed(0)}
              </span>
            </div>
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-center">
              <span className="text-slate-400 block text-[10px]">Projected Annual</span>
              <span className="text-base font-bold text-emerald-400 font-mono-val">
                {settings.currencySymbol}{(currentTotalCost * 365).toFixed(0)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Energy Saving Opportunities & Recommendations */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Lightbulb className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Automated Energy Optimization Recommendations
                <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-medium">
                  SIMULATED ESTIMATES
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Rule-based recommendations to eliminate vacant waste and peak demand penalties
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {SAVINGS_RECOMMENDATIONS.map(rec => {
            const isApplied = appliedRecs[rec.id];

            return (
              <div
                key={rec.id}
                className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20 uppercase">
                      {rec.category}
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono-val font-semibold">
                      {rec.estSavings}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-white mb-1.5">{rec.title}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4">
                    {rec.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 italic">Estimate</span>
                  <button
                    onClick={() => toggleApplyRec(rec.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      isApplied
                        ? 'bg-emerald-600 text-white'
                        : 'bg-cyan-600/20 text-cyan-300 hover:bg-cyan-600/30 border border-cyan-500/30'
                    }`}
                  >
                    {isApplied ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Policy Active</span>
                      </>
                    ) : (
                      <>
                        <span>Apply Policy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
