import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  Cpu, 
  Activity, 
  Users, 
  Zap, 
  Thermometer, 
  Wind, 
  Power, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Sliders, 
  Filter, 
  Search, 
  AlertTriangle,
  Battery,
  ShieldCheck,
  Edit2,
  X
} from 'lucide-react';
import { Sensor, SensorType, SensorThresholds } from '../types';

export const SensorsPage: React.FC = () => {
  const { sensors, labs, updateSensorThresholds, settings } = useIoT();

  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [labFilter, setLabFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [editingSensor, setEditingSensor] = useState<Sensor | null>(null);
  const [thresholdInput, setThresholdInput] = useState<SensorThresholds>({});

  const filteredSensors = sensors.filter(sensor => {
    if (typeFilter !== 'all' && sensor.type !== typeFilter) return false;
    if (labFilter !== 'all' && sensor.labId !== labFilter) return false;
    if (statusFilter === 'online' && !sensor.isOnline) return false;
    if (statusFilter === 'offline' && sensor.isOnline) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return sensor.name.toLowerCase().includes(q) || sensor.id.toLowerCase().includes(q) || sensor.zone.toLowerCase().includes(q);
    }
    return true;
  });

  const getSensorIcon = (type: SensorType) => {
    switch (type) {
      case 'pir_motion':
        return <Activity className="w-4 h-4 text-amber-400" />;
      case 'ir_people_counter':
        return <Users className="w-4 h-4 text-emerald-400" />;
      case 'smart_energy_meter':
        return <Zap className="w-4 h-4 text-cyan-400" />;
      case 'temp_humidity':
        return <Thermometer className="w-4 h-4 text-sky-400" />;
      case 'air_quality':
        return <Wind className="w-4 h-4 text-teal-400" />;
      case 'smart_relay':
        return <Power className="w-4 h-4 text-purple-400" />;
    }
  };

  const getTypeName = (type: SensorType) => {
    switch (type) {
      case 'pir_motion': return 'PIR Motion Sensor';
      case 'ir_people_counter': return 'IR People Counter';
      case 'smart_energy_meter': return '3-Phase Smart Energy Meter';
      case 'temp_humidity': return 'Climate Transducer (DHT/BME)';
      case 'air_quality': return 'VOC & PM2.5 Air Quality';
      case 'smart_relay': return 'Connected Smart Relay/Plug';
    }
  };

  const handleOpenEdit = (sensor: Sensor) => {
    setEditingSensor(sensor);
    setThresholdInput({ ...sensor.thresholds });
  };

  const handleSaveThresholds = () => {
    if (editingSensor) {
      updateSensorThresholds(editingSensor.id, thresholdInput);
      setEditingSensor(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              IoT Telemetry Sensor Array
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono-val">
                {sensors.length} Nodes Configured
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Live status, calibrated thresholds, and signal health across laboratory zones
            </p>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Search box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search sensor ID or zone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl pl-8 pr-3 py-2 w-48 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Type Filter */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All Sensor Types</option>
            <option value="pir_motion">PIR Motion</option>
            <option value="ir_people_counter">IR People Counter</option>
            <option value="smart_energy_meter">Smart Energy Meter</option>
            <option value="temp_humidity">Temp & Humidity</option>
            <option value="air_quality">Air Quality (VOC/PM)</option>
            <option value="smart_relay">Smart Relay / Plug</option>
          </select>

          {/* Lab Filter */}
          <select
            value={labFilter}
            onChange={(e) => setLabFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All Labs</option>
            {labs.map(l => (
              <option key={l.id} value={l.id}>{l.code}</option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All Status</option>
            <option value="online">Online Only</option>
            <option value="offline">Offline Disconnected</option>
          </select>
        </div>
      </div>

      {/* Disconnected Sensor Banner (if any) */}
      {sensors.some(s => !s.isOnline) && (
        <div className="bg-rose-950/30 border border-rose-500/40 rounded-xl p-3 flex items-center justify-between text-xs text-rose-300">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            <span>
              <strong>Hardware Alert:</strong> {sensors.filter(s => !s.isOnline).length} sensor(s) are currently unreachable or stale. Simulated mock values are never substituted for offline hardware.
            </span>
          </div>
          <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded font-mono-val font-bold">
            CHECK BUS GATEWAY
          </span>
        </div>
      )}

      {/* Sensor Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSensors.map(sensor => {
          const lab = labs.find(l => l.id === sensor.labId);
          const isWarning = sensor.thresholds.warningHigh !== undefined && sensor.value > sensor.thresholds.warningHigh;

          return (
            <div
              key={sensor.id}
              className={`bg-slate-900/80 border rounded-2xl p-5 shadow-lg flex flex-col justify-between transition-all ${
                !sensor.isOnline
                  ? 'border-rose-900/50 opacity-80'
                  : isWarning
                  ? 'border-amber-500/50 bg-amber-950/10'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                {/* Header: Type icon & Online Status */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 flex-shrink-0">
                      {getSensorIcon(sensor.type)}
                    </div>
                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                        {getTypeName(sensor.type)}
                      </span>
                      <h3 className="text-sm font-bold text-white leading-tight truncate max-w-[180px]">
                        {sensor.name}
                      </h3>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 ${
                      sensor.isOnline 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    }`}>
                      {sensor.isOnline ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                      {sensor.isOnline ? 'ONLINE' : 'OFFLINE'}
                    </span>
                  </div>
                </div>

                {/* ID & Zone Tag */}
                <div className="flex items-center justify-between text-xs text-slate-400 mb-4 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800/60 font-mono-val text-[11px]">
                  <span>ID: <code className="text-cyan-400">{sensor.id}</code></span>
                  <span className="text-slate-300 truncate max-w-[120px]">{lab?.code} • {sensor.zone}</span>
                </div>

                {/* Primary Reading Display */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 mb-3">
                  <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
                    <span>Active Telemetry Reading</span>
                    {sensor.batteryLevel !== undefined && (
                      <span className="text-[10px] text-slate-400 flex items-center gap-1">
                        <Battery className="w-3 h-3 text-emerald-400" /> {sensor.batteryLevel}%
                      </span>
                    )}
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl md:text-3xl font-extrabold text-white font-mono-val">
                      {sensor.isOnline ? sensor.value : '---'}
                    </span>
                    <span className="text-sm font-bold text-cyan-400">{sensor.unit}</span>
                  </div>

                  {sensor.secondaryValue !== undefined && sensor.isOnline && (
                    <div className="mt-2 text-xs text-slate-400 font-mono-val pt-2 border-t border-slate-800/80">
                      Secondary: <strong className="text-slate-200">{sensor.secondaryValue} {sensor.secondaryUnit}</strong>
                    </div>
                  )}
                </div>

                {/* Waveform Sparkline history */}
                {sensor.history && sensor.history.length > 0 && sensor.isOnline && (
                  <div className="mb-3">
                    <span className="text-[10px] text-slate-400 block mb-1">Recent Sensor Waveform:</span>
                    <div className="flex items-end gap-1 h-9 bg-slate-950/40 p-1.5 rounded-lg border border-slate-800/50">
                      {sensor.history.map((h, i) => (
                        <div
                          key={i}
                          className="flex-1 bg-cyan-500/40 hover:bg-cyan-400 rounded-t transition-colors"
                          style={{ height: `${Math.max(15, Math.min(100, (h.value / (sensor.value || 1)) * 75))}%` }}
                          title={`${h.value} ${sensor.unit} at ${h.time}`}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Threshold info and edit button */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400 text-[11px] flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-500" />
                  {sensor.lastUpdated}
                </span>

                <button
                  onClick={() => handleOpenEdit(sensor)}
                  className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-medium text-xs bg-slate-950 px-2 py-1 rounded-lg border border-slate-800 hover:border-cyan-500/40 transition-colors"
                >
                  <Sliders className="w-3 h-3" />
                  <span>Thresholds</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Threshold Config Modal */}
      {editingSensor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                Configure Safety Thresholds
              </h3>
              <button
                onClick={() => setEditingSensor(null)}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Set automated warning thresholds for <strong className="text-white">{editingSensor.name}</strong> ({editingSensor.unit}).
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="text-xs text-slate-300 block mb-1">Warning High Limit ({editingSensor.unit})</label>
                <input
                  type="number"
                  value={thresholdInput.warningHigh ?? ''}
                  onChange={(e) => setThresholdInput(prev => ({ ...prev, warningHigh: e.target.value ? parseFloat(e.target.value) : undefined }))}
                  placeholder="e.g. 24.5"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 block mb-1">Critical High Limit ({editingSensor.unit})</label>
                <input
                  type="number"
                  value={thresholdInput.criticalHigh ?? ''}
                  onChange={(e) => setThresholdInput(prev => ({ ...prev, criticalHigh: e.target.value ? parseFloat(e.target.value) : undefined }))}
                  placeholder="e.g. 27.0"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setEditingSensor(null)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveThresholds}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-950"
              >
                Save Thresholds
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
