import React, { useState } from 'react';
import { useIoT } from '../context/IoTContext';
import { 
  Power, 
  Zap, 
  Clock, 
  AlertTriangle, 
  ShieldCheck, 
  Sliders, 
  CheckCircle2, 
  XCircle, 
  Search, 
  Check, 
  RotateCcw,
  Sparkles,
  Timer
} from 'lucide-react';
import { Device, DeviceCategory } from '../types';
import { ConfirmationModal } from '../components/common/ConfirmationModal';

export const DevicesPage: React.FC = () => {
  const { 
    devices, 
    labs, 
    toggleDeviceState, 
    updateDeviceAutoShutoff, 
    currentUser,
    settings 
  } = useIoT();

  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [labFilter, setLabFilter] = useState<string>('all');
  const [stateFilter, setStateFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Confirmation Modal state
  const [pendingAction, setPendingAction] = useState<{
    device: Device;
    targetState: 'ON' | 'OFF';
  } | null>(null);
  const [isDispatching, setIsDispatching] = useState<boolean>(false);

  // Auto-shutoff editor modal
  const [editingAutoShutoff, setEditingAutoShutoff] = useState<Device | null>(null);
  const [autoShutoffEnabled, setAutoShutoffEnabled] = useState<boolean>(false);
  const [autoShutoffDelay, setAutoShutoffDelay] = useState<number>(15);

  const filteredDevices = devices.filter(dev => {
    if (categoryFilter !== 'all' && dev.category !== categoryFilter) return false;
    if (labFilter !== 'all' && dev.labId !== labFilter) return false;
    if (stateFilter !== 'all' && dev.state !== stateFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return dev.name.toLowerCase().includes(q) || dev.id.toLowerCase().includes(q) || dev.zone.toLowerCase().includes(q);
    }
    return true;
  });

  const handlePromptToggle = (device: Device) => {
    if (currentUser.role === 'researcher') {
      alert('Access Restricted: Only Lab Administrators and Facility Ops can toggle instrument power relays.');
      return;
    }
    const targetState = device.state === 'ON' ? 'OFF' : 'ON';
    setPendingAction({ device, targetState });
  };

  const handleConfirmToggle = async () => {
    if (!pendingAction) return;
    setIsDispatching(true);
    await toggleDeviceState(pendingAction.device.id, pendingAction.targetState);
    setIsDispatching(false);
    setPendingAction(null);
  };

  const handleOpenAutoShutoff = (device: Device) => {
    setEditingAutoShutoff(device);
    setAutoShutoffEnabled(device.autoShutoffVacant);
    setAutoShutoffDelay(device.vacancyShutoffDelayMinutes || 15);
  };

  const handleSaveAutoShutoff = () => {
    if (editingAutoShutoff) {
      updateDeviceAutoShutoff(editingAutoShutoff.id, autoShutoffEnabled, autoShutoffDelay);
      setEditingAutoShutoff(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Power className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Connected Laboratory Equipment & Relays
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono-val">
                {devices.length} Connected
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Hardware relay actuators, automated vacancy shutoff rules, and real-time load shedding
            </p>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Search box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search equipment or zone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl pl-8 pr-3 py-2 w-48 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All Categories</option>
            <option value="fume_hood">Fume Hoods</option>
            <option value="centrifuge">Centrifuges</option>
            <option value="freezer">Freezers & Cold Storage</option>
            <option value="hvac">HVAC / Air Handling</option>
            <option value="analyzer">Analyzers & Spectrometers</option>
            <option value="relay_plug">Smart Plugs & Relays</option>
            <option value="lighting">Lighting</option>
          </select>

          {/* Lab Filter */}
          <select
            value={labFilter}
            onChange={(e) => setLabFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All Labs</option>
            {labs.map(l => (
              <option key={l.id} value={l.id}>{l.code}</option>
            ))}
          </select>

          {/* State Filter */}
          <select
            value={stateFilter}
            onChange={(e) => setStateFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-2 font-medium"
          >
            <option value="all">All States</option>
            <option value="ON">ON Active</option>
            <option value="STANDBY">Standby</option>
            <option value="OFF">OFF Disabled</option>
          </select>
        </div>
      </div>

      {/* Safety Notice Banner */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-3 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-cyan-400" />
          <span>
            <strong>Safety Interlock Protocol:</strong> All device switching requires cryptographic confirmation before dispatching commands via MQTT relay coils. Critical samples are protected.
          </span>
        </div>
        <span className="text-[10px] text-cyan-400 font-mono-val">
          ROLE: {currentUser.role.toUpperCase()}
        </span>
      </div>

      {/* Devices Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDevices.map(device => {
          const lab = labs.find(l => l.id === device.labId);
          const isCritical = device.category === 'freezer' || device.name.includes('-80°C');

          return (
            <div
              key={device.id}
              className={`bg-slate-900/80 border rounded-2xl p-5 shadow-lg flex flex-col justify-between transition-all ${
                device.state === 'ON'
                  ? 'border-slate-800 hover:border-cyan-500/40'
                  : 'border-slate-800/60 opacity-80'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                      {device.category.replace('_', ' ')}
                    </span>
                    <h3 className="text-sm font-bold text-white leading-tight mt-0.5">
                      {device.name}
                    </h3>
                  </div>

                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    device.state === 'ON' 
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                      : device.state === 'STANDBY'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}>
                    {device.state}
                  </span>
                </div>

                {/* ID & Zone Tag */}
                <div className="flex items-center justify-between text-xs text-slate-400 mb-4 bg-slate-950/60 px-3 py-1.5 rounded-lg border border-slate-800/60 font-mono-val text-[11px]">
                  <span>ID: <code className="text-cyan-400">{device.id}</code></span>
                  <span className="text-slate-300 truncate max-w-[130px]">{lab?.code} • {device.zone}</span>
                </div>

                {/* Power Reading Display */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 mb-3">
                  <div className="text-xs text-slate-400 mb-1 flex items-center justify-between">
                    <span>Active Power Draw</span>
                    <span className="text-[10px] text-slate-400 font-mono-val">
                      Rated: {device.nominalWatts} W
                    </span>
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl md:text-3xl font-extrabold text-white font-mono-val">
                      {device.powerWatts}
                    </span>
                    <span className="text-sm font-bold text-cyan-400">Watts</span>
                    <span className="text-xs text-slate-500">
                      ({(device.powerWatts / 1000).toFixed(2)} kW)
                    </span>
                  </div>

                  <div className="mt-2 text-xs text-slate-400 font-mono-val pt-2 border-t border-slate-800/80 flex items-center justify-between">
                    <span>Daily Accumulation:</span>
                    <strong className="text-slate-200">{device.dailyKwh} kWh</strong>
                  </div>
                </div>

                {/* Vacancy Auto-shutoff rule status */}
                <div className="bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60 mb-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <Timer className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Vacancy Auto-Shutoff:</span>
                  </div>
                  <button
                    onClick={() => handleOpenAutoShutoff(device)}
                    className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300 underline underline-offset-2"
                  >
                    {device.autoShutoffVacant ? `Active (${device.vacancyShutoffDelayMinutes}m)` : 'Disabled'}
                  </button>
                </div>
              </div>

              {/* Action Switch Button */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400 text-[11px] flex items-center gap-1 font-mono-val">
                  <Clock className="w-3 h-3 text-slate-500" />
                  {device.lastCommunication}
                </span>

                <button
                  onClick={() => handlePromptToggle(device)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs shadow-md transition-all ${
                    device.state === 'ON'
                      ? 'bg-rose-600/20 text-rose-300 hover:bg-rose-600/30 border border-rose-500/30'
                      : 'bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 border border-emerald-500/30'
                  }`}
                >
                  <Power className="w-3.5 h-3.5" />
                  <span>Turn {device.state === 'ON' ? 'OFF' : 'ON'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Safety Confirmation Dialog */}
      {pendingAction && (
        <ConfirmationModal
          isOpen={true}
          title={`Confirm Relay Power ${pendingAction.targetState}`}
          message={
            pendingAction.targetState === 'OFF'
              ? `Are you sure you want to disconnect power to "${pendingAction.device.name}" (${pendingAction.device.id}) in ${pendingAction.device.zone}? Ensure no active assays or hazardous reactions are underway.`
              : `Confirm power activation for "${pendingAction.device.name}". Relay contact will energize.`
          }
          confirmLabel={`Yes, Turn ${pendingAction.targetState}`}
          cancelLabel="Cancel"
          isDestructive={pendingAction.targetState === 'OFF'}
          isLoading={isDispatching}
          onConfirm={handleConfirmToggle}
          onCancel={() => setPendingAction(null)}
        />
      )}

      {/* Vacancy Auto-Shutoff Configuration Modal */}
      {editingAutoShutoff && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
              <Timer className="w-4 h-4 text-cyan-400" />
              Configure Automated Vacancy Shutoff
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Automatically shut off <strong className="text-white">{editingAutoShutoff.name}</strong> if the laboratory remains vacant.
            </p>

            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="text-xs font-semibold text-slate-200">Enable Vacancy Auto-Shutoff</span>
                <input
                  type="checkbox"
                  checked={autoShutoffEnabled}
                  onChange={(e) => setAutoShutoffEnabled(e.target.checked)}
                  className="w-4 h-4 rounded text-cyan-500 focus:ring-0 bg-slate-800 border-slate-700"
                />
              </div>

              {autoShutoffEnabled && (
                <div>
                  <label className="text-xs text-slate-300 block mb-1">
                    Vacancy Delay Period (Minutes before shutoff):
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="180"
                    value={autoShutoffDelay}
                    onChange={(e) => setAutoShutoffDelay(parseInt(e.target.value) || 15)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Default recommended: 15 to 30 minutes to allow researcher re-entry.
                  </p>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setEditingAutoShutoff(null)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveAutoShutoff}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-950"
              >
                Save Shutoff Policy
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
