export type SensorType = 
  | 'pir_motion' 
  | 'ir_people_counter' 
  | 'smart_energy_meter' 
  | 'temp_humidity' 
  | 'air_quality' 
  | 'smart_relay';

export type OccupancyStatus = 'Occupied' | 'Partially Occupied' | 'Vacant' | 'Unknown';

export type AlertSeverity = 'critical' | 'warning' | 'info';

export type AlertType = 
  | 'energy_spike' 
  | 'vacant_waste' 
  | 'occupancy_limit' 
  | 'sensor_offline' 
  | 'abnormal_temp' 
  | 'abnormal_humidity' 
  | 'power_threshold';

export type DeviceCategory = 
  | 'fume_hood' 
  | 'centrifuge' 
  | 'freezer' 
  | 'hvac' 
  | 'analyzer' 
  | 'relay_plug' 
  | 'lighting';

export interface SensorThresholds {
  warningHigh?: number;
  warningLow?: number;
  criticalHigh?: number;
  criticalLow?: number;
}

export interface SensorReadingHistory {
  time: string;
  value: number;
}

export interface Sensor {
  id: string;
  name: string;
  type: SensorType;
  labId: string;
  zone: string;
  isOnline: boolean;
  lastUpdated: string;
  batteryLevel?: number;
  value: number;
  unit: string;
  secondaryValue?: number;
  secondaryUnit?: string;
  thresholds: SensorThresholds;
  history: SensorReadingHistory[];
  isSimulated?: boolean;
}

export interface Device {
  id: string;
  name: string;
  labId: string;
  zone: string;
  category: DeviceCategory;
  powerWatts: number;
  nominalWatts: number;
  state: 'ON' | 'OFF' | 'STANDBY';
  connectivity: 'online' | 'offline';
  lastCommunication: string;
  autoShutoffVacant: boolean;
  vacancyShutoffDelayMinutes: number;
  dailyKwh: number;
  isSimulated?: boolean;
}

export interface Lab {
  id: string;
  name: string;
  code: string;
  building: string;
  floor: string;
  maxOccupancy: number;
  currentOccupancy: number;
  occupancyStatus: OccupancyStatus;
  targetTemp: number; // in °C
  targetHumidity: number; // in %
  totalPowerWatts: number;
  dailyKwh: number;
  operatingHours: {
    start: string; // e.g. "08:00"
    end: string;   // e.g. "19:00"
  };
  zones: string[];
  alertCount: number;
}

export interface Alert {
  id: string;
  timestamp: string;
  labId: string;
  labName: string;
  deviceId?: string;
  deviceName?: string;
  sensorId?: string;
  sensorName?: string;
  type: AlertType;
  severity: AlertSeverity;
  description: string;
  recommendedAction: string;
  acknowledged: boolean;
  resolved: boolean;
}

export interface SystemSettings {
  electricityTariff: number; // price per kWh
  currency: string; // $, €, £, ¥
  currencySymbol: string;
  vacancyDelayMinutes: number;
  peakPowerThresholdWatts: number;
  emailAlertsEnabled: boolean;
  soundEnabled: boolean;
  demoMode: boolean; // true = simulated data generator active; false = live mode waiting for MQTT/REST
  simulationSpeed: number; // 1x, 2x, 5x
  autoDetectWaste: boolean;
  mqttBrokerUrl: string;
  mqttPort: number;
  mqttTopicRoot: string;
  restWebhookKey: string;
}

export interface HourlyTelemetry {
  time: string;
  powerKw: number;
  occupancy: number;
  baseLoadKw: number;
  cost: number;
  occupiedPowerKw: number;
  vacantPowerKw: number;
  previousDayKw: number;
  energyPerPersonKwh: number;
}

export type UserRole = 'admin' | 'researcher' | 'facility_manager';

export interface UserProfile {
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
}
